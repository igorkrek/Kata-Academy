
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class Main {
    public static void main(String[] args) {


        Class2 class2 = new Class2();
        classInfoShow(class2.getClass());
    }

    public static void classInfoShow(Class claSS) {

        System.out.println(claSS.getSimpleName());
        for (Field field : claSS.getDeclaredFields()) {
            if (field.isAnnotationPresent(FilterIt.class)) {
                FilterIt f = field.getAnnotation(FilterIt.class);
                if (f.show()) {
                    System.out.println(field.getName());
                }
            }
        }
        for (Method method : claSS.getDeclaredMethods()) {
            if (method.isAnnotationPresent(FilterIt.class)) {
                FilterIt f = method.getAnnotation(FilterIt.class);

                if (f.show()) {
                    System.out.println(method.getName());
                }
            }
        }


        if (claSS.getSuperclass() != null) classInfoShow(claSS.getSuperclass());
    }
}



