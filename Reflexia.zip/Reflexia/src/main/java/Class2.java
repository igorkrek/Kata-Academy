public class Class2 extends Class1{
    @FilterIt(show = true)
    String field21;
    @FilterIt(show = true)
    Object field22;
    @FilterIt(show = true)
    int field23;

    @FilterIt(show = true)
    String method21() {
        return " ";
    }

    @FilterIt(show = true)
    int method22() {
        return 0;
    }

    @FilterIt(show = true)
    Double method23() {
        return 0.0;
    }
}
