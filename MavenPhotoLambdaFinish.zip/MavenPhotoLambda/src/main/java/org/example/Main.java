/*
Продолжая работу над ботом из предыдущих уроков реализуйте дополнительный фильтр
для обработки изображения при помощи которого отправленное  изображение пользователя
при соответствующей команде с его стороны,
  будет перекрашено в красный цвет (наложен красный фильтр) как это показано в уроке
 */
package org.example;

import org.telegram.telegrambots.meta.TelegramBotsApi;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;
import org.telegram.telegrambots.meta.generics.BotSession;
import org.telegram.telegrambots.updatesreceivers.DefaultBotSession;



public class Main {
    public static void main(String[] args) throws TelegramApiException {

        System.out.println("Это мой первый проект на Maven");
        TelegramBotsApi api = new TelegramBotsApi(DefaultBotSession.class);
        BotSession botSession = api.registerBot(new Bot());






    }
}