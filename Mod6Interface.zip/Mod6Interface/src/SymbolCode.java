import java.util.Arrays;
import java.util.stream.Collectors;

public class SymbolCode implements CoderDecoder{

    public	String encode(String source) {
        char [] str = source.toCharArray();
        int [] code = new int[str.length];
        for(int i = 0; i < str.length; i++) {
            code[i] = (int) str[i];
            source = Arrays.toString(code);
           }
        System.out.println(source);
        return source;
    }

    public String decode(String encoded){
      String [] strCod = encoded.split(",");
        encoded = Arrays.stream(strCod).mapToInt((a) -> Integer.parseInt(a)).mapToObj(x -> (char) x).map(x -> Character.toString(x)).collect(Collectors.joining());
        System.out.println(encoded);
      return encoded;
    }

}





