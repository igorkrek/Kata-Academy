public class CodeDecodeChar implements CoderDecoder {


    public	String encode(String source) {
        char [] str = source.toCharArray();char l;
        for(char e : str) {
            if (((int) e) > 126) {
                l = (char) (((int) e) - 975);
                source = source.replace(e,l);
            }
        }
        return source;
    }

    public String decode(String encoded){
        char [] str = encoded.toCharArray();char l;
        for(char e : str) {
            if (((int) e) < 126) {
                l = (char) (((int) e) + 975);
                encoded = encoded.replace(e,l);
            }
        }
        return encoded;
    }

}




