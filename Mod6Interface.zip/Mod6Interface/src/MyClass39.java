public class MyClass39 {
    public void MyClass39() {
        TableScanner tableScanner = new TableScanner();
        System.out.println("Please, enter table...");
        Row[] table = tableScanner.scanTable();
        TableWriter tableWriter = new ConsolTableWriter();
        tableWriter.writeTable(table);
        System.out.println("Table written to" + tableWriter.getOutputPlace());

    }
}