import java.util.Arrays;
import static java.lang.Math.*;
public class ConsolTableWriter implements TableWriter{
    @Override
    public void writeTable (Row [] table) {
        int maxSize = Math.max(
                Arrays.stream(table).map(a -> a.left).map(a -> a.toString().length()).mapToInt(a -> a).max().getAsInt(),
        Arrays.stream(table).map(a -> a.right).map(a -> a.toString().length()).mapToInt(a -> a).max().getAsInt());
        System.out.println("Max:" + maxSize);

        for (int i = 0; i < table.length; i++) {
        Row current = table[i];
        System.out.println(padRight(current.left,maxSize) + "|" + padLeft(current.right,maxSize));
    }

    }

@Override
   public String getOutputPlace () {
return "console";

}
public static String padRight(String s, int n) {
    return String.format("%-" + n + "s", s);
}

    public static String padLeft(String s, int n) {
        return String.format("%" + n + "s", s);
    }
}
