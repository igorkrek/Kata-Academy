public class Row {
    public String right;
    public String left;
     public Row (String left, String right) {

         this.left = left;
         this.right = right;
     }
}
