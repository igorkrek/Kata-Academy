public interface TableWriter {
  void writeTable (Row [] table);

    String getOutputPlace ();
}
