
public interface CoderDecoder {


    String encode(String source);

    String decode(String encoded);

}