import java.util.Arrays;
import java.util.List;

public class MorseCoderDecoder implements CoderDecoder{

    public String encode(String line) {

        char [] str = line.toCharArray();


        String [] morseLine = {".-","-...",".--","--.","-..",".","...-","--..","..",".---","-.-",".-..","--","-.","---",".--.",".-.","...",
                "-","..-","..-.","....","-.-.","---.","----","--.-",".--.-.","-.--","-..-","..--..","..--",".-.-"};


        for(char e : str) {
            line = line.replace(Character.toString(e),morseLine[((int) e) - 1072] + " ");
        }

        return line;
    }



    public String decode(String line){
        String [] morseStr = line.split(" ");
        String [] morseLine = {".-","-...",".--","--.","-..",".","...-","--..","..",".---","-.-",".-..","--","-.","---",".--.",".-.","...",
                "-","..-","..-.","....","-.-.","---.","----","--.-",".--.-.","-.--","-..-","..--..","..--",".-.-"};



        for(int j = 0; j < morseStr.length; j++) {
           for (int i = 0; i < morseLine.length; i++) {
               if (morseStr[j].equals(morseLine[i])) {
                 morseStr[j] = Character.toString((char) 1072 + i);

               }

           }


        }
        line = Arrays.toString(morseStr) ;
        return line;
    }
}