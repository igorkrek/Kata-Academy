import java.util.Scanner;
public class Main {


    public static void main(String[] args) {
        System.out.println("Hello tetris!");
        System.out.println("вниз-'2', вправо-'6',влево-'4'.");
        Scanner scan = new Scanner(System.in);
        field f = new field();
        figure s = new figure();
         boolean gamecontr=true;
        int count = 0;
        boolean runcontr;
        f.fieldInitialize();
        while (gamecontr){
            s.initFigure(f.field);
            System.out.println("Game! count:"+count);
            f.fieldPrinter();
            runcontr = true;
            while (runcontr) {
               int a = scan.nextInt();
                s.figureRun(f.field, a);
               runcontr = s.runControl(f.field);
               count=count + f.lineControl(f.field);
              gamecontr=f.gameControl(f.field);
                System.out.println("Game! count:"+count);
                f.fieldPrinter();
            }


        }
        System.out.println("game over. счет: "+count);
    }
}