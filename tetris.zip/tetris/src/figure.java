import java.util.Random;
public class figure {
    int sizeFigure = 9, count = 10;
    boolean stopRun = false;

    String fig = null;

    public void initFigure(String[][] s) {

        Random random = new Random();
        int coordinateX = 0;
        int coordinateY = random.nextInt(4) + 1;
        int typeFigure = random.nextInt(9);
        switch (typeFigure) {
            case 0:
                this.fig = "***.*......  ";
                System.out.println("Cross");
                break;
            case 1:
                this.fig = "**.*......  ";
                System.out.println("CornerR");
                break;
            case 2:
                this.fig = "***.......  ";
                System.out.println("Cygar");
                break;
            case 3:
                this.fig = "..*.......  ";
                System.out.println("Point");
                break;
            case 4:
                this.fig = "**..**....  ";
                System.out.println("Four");
                break;
            case 5:
                this.fig = "*..***..*.  ";
                System.out.println("Segment");
                break;
            case 6:
                this.fig = "**........  ";
                System.out.println("Two");
                break;
            case 7:
                this.fig = "*..*..*...  ";
                System.out.println("Column");
                break;
            case 8:
                this.fig = ".**..*...  ";
                System.out.println("CornerL");
                break;
            default:
                break;
        }
        figurePosition(s, coordinateX, coordinateY, fig);

    }

    public void figurePosition(String[][] s, int coordinateX, int coordinateY, String fig) {
        int symbol = 0;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                s[coordinateX + i][coordinateY + j] = " " + this.fig.substring(symbol, symbol + 1) + " ";
                symbol++;
            }
        }
    }

    public void figureRun(String[][] s, int a) {
        if (a == 2) {//вниз
            for (int i = 9; i >= 0; i--) {
                for (int j = 0; j < 10; j++) {
                    if (s[i][j].contains("*")) {
                        s[i + 1][j] = s[i][j];
                        s[i][j] = " . ";
                    }
                }
            }
        }
        if ((a == 4)&(granR(s,0))) {//влево
            for (int i = 0; i < 10; i++) {
                for (int j = 0; j <10; j++) {
                    if (s[i][j].contains("*")) {
                        
                        s[i][j - 1] = s[i][j];
                        s[i][j] = " . ";
                    }
                }
            }
        }
        if ((a == 6)&(granR(s,9))){//вправо
            for (int i = 0; i < 10; i++) {
                for (int j = 9; j >= 0; j--) {
                    
                    if (s[i][j].contains("*")) {
                         s[i][j + 1] = s[i][j];
                        s[i][j] = " . ";
                    }
                }
            }
        }
    }
    public boolean runControl(String[][] s) {
        boolean runContr = true;
        for (int i = 0; i < 9 & runContr; i++) {
            for (int j = 0; j < 10 & runContr; j++) {
                if (s[i][j].contains("*") & s[i + 1][j].contains("#")) {
                    runContr = false;
                    for (int x = 0; x < 10; x++) {
                        for (int y = 0; y < 10; y++) {
                            if (s[x][y].contains("*")) {
                                s[x][y]=" # ";
                            }
                        }
                    }
                }


            }


        }
        return runContr;

    }
    
    
    
    public boolean granR(String[][]s,int num){
        boolean c=true;
        for (int i=0;i<10;i++){
            if ( s[i][num].contains("*")){c=false;break;}
        }return c;
    
    }
    
    
    
    
}





