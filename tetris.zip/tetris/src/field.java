import java.util.Random;

public class field {
    String[][] field = new String[10][10];

    public void fieldPrinter() {
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                System.out.print(this.field[i][j]);
            }
            System.out.println();
        }
    }

    public void fieldInitialize() {
        Random random = new Random();
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                this.field[i][j] = " . ";
            }
        }
        for (int i = 0; i <= 9; i++) {
            this.field[8][random.nextInt(9)] = " # ";
            this.field[9][i] = " # ";
        }
        fieldPrinter();
    }

    public int lineControl(String[][] s) {
        int line=0,count=0;
        for (int i = 0; i<9; i++) {int flag = 0;

            for (int j = 0; j < 10; j++) {
               if (s[i][j].contains("#")) {flag++;}
               }
            if (flag>9){line=i;break;};
                }

            if (line>0) {count=100;
                for (int i = line; i > 0; i--) {
                    for (int j = 0; j < 10; j++) {
                         s[i][j] = s[i-1][j];

                        s[0][j] = " . ";
                    }
                }


            }
return count;
        }
    
    
   public boolean gameControl(String[][] s) {
        int flag=0;boolean b=true;
        for (int i=0;i<9;i++) {
            if (s[1][i].contains("#")) {flag++;}}
       
            if (flag>0){ b= false;}
       return b;
   }
    

}







