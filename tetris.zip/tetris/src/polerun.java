
public class polerun {
    public void poleRun(String [][] s, int a){
                if (a==2){
            for (int i=8;i>0;i--){
            for(int j=0;j<9;j++){
                if (s[i][j].contains("*")){s[i+1][j]=s[i][j];s[i][j]=" . ";}
                    
            }
            }
                    
    }
        if(a==6){
            for (int i=8;i>0;i--){
            for(int j=0;j<9;j++){
                if (s[i][j].contains("*")){s[i+1][j]=s[i][j];s[i][j]=" . ";}
                    
            }
            }
                    
    }
    }
}