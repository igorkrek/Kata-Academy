package com.example.quotes.services;

import com.example.quotes.models.Quote;
import com.example.quotes.repositories.QuoteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Component
public class QuoteService {

    @Autowired
    BashParcer parcer;
    @Autowired
    QuoteRepository repository;

    public List<Quote> getPage(int page) throws IOException {
        List<Quote> ret = new ArrayList<>();
        Map<Integer, String> map = parcer.getPage(page);
        for (var entry : map.entrySet()) {
            var rowQuote = new Quote();
            rowQuote.setQuoteId(entry.getKey());
            rowQuote.setText(entry.getValue());
            var existed = repository.findByQuoteIdEquals(rowQuote.getQuoteId());
            if (existed.isEmpty()) {
                ret.add(repository.save(rowQuote));
            }else ret.add(existed.get());
        }
        return ret;
    }
        public Quote getById(int id) throws IOException {
        var existingQuote = repository.findByQuoteIdEquals(id);
        if(existingQuote.isPresent()) return existingQuote.get();
                var quoteEntery = parcer.getById(id);
                if(quoteEntery == null) return null;
                var newQuote = new Quote();
                newQuote.setQuoteId(quoteEntery.getKey());
                newQuote.setText(quoteEntery.getValue());
                return repository.save(newQuote);
            }
    public Quote getRandom() throws IOException {

        var quoteEntery = parcer.getRandom();
        if(quoteEntery == null) return null;

        var existingQuote = repository.findByQuoteIdEquals(quoteEntery.getKey());
        if(existingQuote.isPresent()) return existingQuote.get();
        var newQuote = new Quote();
        newQuote.setQuoteId(quoteEntery.getKey());
        newQuote.setText(quoteEntery.getValue());
        return repository.save(newQuote);
    }
            }








