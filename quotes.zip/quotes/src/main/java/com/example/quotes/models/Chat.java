package com.example.quotes.models;

import jakarta.persistence.*;


@Entity
@Table(name = "\"Chats2\"")
public class Chat {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column (name = "id", nullable = false)
    public long id;
    @Column (name = "\"chatId\"", nullable = false)
    public long chatId;
    @Column (name = "\"lastId\"", nullable = false)
    public Integer lastId;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setChatId(long chatId) {
        this.chatId = chatId;
    }

    public void setLastId(Integer lastId) {
        this.lastId = lastId;
    }

    public long getChatId() {
        return chatId;
    }

    public Integer getLastId() {
        return lastId;
    }
}
