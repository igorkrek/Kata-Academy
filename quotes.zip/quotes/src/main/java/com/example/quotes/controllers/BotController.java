package com.example.quotes.controllers;

import com.example.quotes.models.Chat;
import com.example.quotes.models.Quote;
import com.example.quotes.repositories.ChatRepository;
import com.example.quotes.services.QuoteService;
import com.pengrad.telegrambot.TelegramBot;
import com.pengrad.telegrambot.UpdatesListener;
import com.pengrad.telegrambot.model.Update;
import com.pengrad.telegrambot.request.SendMessage;
import com.pengrad.telegrambot.response.SendResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
@Service
public class BotController {
    public TelegramBot bot;
    @Autowired
    ChatRepository chatRepository;
    @Autowired
    QuoteService service;

    public BotController() {
        bot = new TelegramBot("6020497059:AAGmjXTPaSv70garwhIK67Z3Vh3qNKCdjm0");
        bot.setUpdatesListener(updates -> {
            for (Update update : updates) {
                handleUpdate(update);
            }
            return UpdatesListener.CONFIRMED_UPDATES_ALL;
        });
    }

    public void handleUpdate(Update update) {
        String text = update.message().text();
        long chatId = update.message().chat().id();


        var rawChat = chatRepository.findByChatIdEquals(chatId);
        Chat chat;
        if (rawChat.isPresent()) {
            chat = rawChat.get();
        } else {
            var _chat = new Chat();
            _chat.setChatId(chatId);
            _chat.setLastId(0);
            chat = chatRepository.save(_chat);
        }
            switch(text){
                case "/start": sendNextQuote(chat);break;
                case "/next": sendNextQuote(chat);break;
                case "/prev": sendPrevQuote(chat); break;
                case "/rand": sendRandom(chat); break;

            }
} private void sendPrevQuote (Chat chat){
        Quote quote = null;
        int newId = chat.getLastId();
        while ((quote == null)){
            newId--;
            if(newId < 2) newId = 2;

            try {
                quote = service.getById(newId);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

        }
        chat.setLastId(quote.getQuoteId());
        chatRepository.save(chat);
        sendText(chat.getChatId(), quote.getText());
    }
        private void sendNextQuote (Chat chat){
            Quote quote = null;
            int newId = chat.getLastId();
            while ((quote == null)){
                            newId++;
                try {
                    quote = service.getById(newId);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }

            }
            chat.setLastId(quote.getQuoteId());
                chatRepository.save(chat);
                sendText(chat.getChatId(), quote.getText());
        }

        private void   sendText(Long chatId, String text){
            bot.execute(new SendMessage(chatId,text));

        }

    private void sendRandom (Chat chat){
        Quote quote = null;
        try {
            quote = service.getRandom();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        sendText(chat.getChatId(), quote.getText());
    }



//    t.me/sssStalkerTestSuper_bot.
//    Use this token to access the HTTP API:
//            6020497059:AAGmjXTPaSv70garwhIK67Z3Vh3qNKCdjm0
//    For a description of the Bot API, see this page: https://core.telegram.org/bots/api

}
