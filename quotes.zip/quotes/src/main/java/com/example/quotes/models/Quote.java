package com.example.quotes.models;

import jakarta.persistence.*;


@Entity
@Table(name = "\"Quotes2\"")
public class Quote {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column (name = "id", nullable = false)
    public Integer id;

    public Integer getQuoteId() {
        return quoteId;
    }

    @Column (name = "text", nullable = false)
    public String text;

    public void setQuoteId(Integer quoteId) {
        this.quoteId = quoteId;
    }

    @Column (name = "\"quoteId\"", nullable = false)
    public Integer quoteId;


    public Integer getId() {
        return id;
    }

    public String getText() {
        return text;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setText(String text) {
        this.text = text;
    }
}
