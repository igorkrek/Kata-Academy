package com.example.quotes.repositories;

import com.example.quotes.models.Chat;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ChatRepository extends JpaRepository<Chat,Long> {
    Optional<Chat> findByChatIdEquals(long chatId);

}
