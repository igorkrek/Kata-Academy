package com.example.quotes.services;

import jakarta.persistence.criteria.CriteriaBuilder;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.AbstractMap;
import java.util.HashMap;
import java.util.Map;


@Component
public class BashParcer {


    public Map<Integer, String> getPage (int page) {
        Map<Integer, String> quotes = new HashMap<>();
        try {
            Document doc = Jsoup.connect("http://ibash.org.ru/?page=" + page).get();

            System.out.println(doc.title());
            Elements sourceQuotes = doc.select(".quote");

            for (Element quoteElement : sourceQuotes) {
                int id = Integer.parseInt(quoteElement.select("b").first().text().substring(1));
                System.out.println(id);
                String text = quoteElement.select(".quotbody").first().text();
                quotes.put(id, text);
                System.out.println(text);
            }
        }catch(IOException ignored){
        }
         return quotes;
    }
    public Map.Entry<Integer, String> getById (int id) throws IOException {


        try {
            Document doc = Jsoup.connect("http://ibash.org.ru/quote.php?id=" + id).get();
            Element quoteElement = doc.select(".quote").first();
            String realId = quoteElement.select("b").first().text();
            if(realId.equals("#???")) return null;
            String text = quoteElement.select(".quotbody").first().text();
            return new AbstractMap.SimpleEntry<>(id, text);
        }catch (IOException e){
            e.printStackTrace();
        }
        return null;

            }

    public Map.Entry<Integer, String> getRandom () throws IOException {
        try {
            Document doc = Jsoup.connect("http://ibash.org.ru/random.php").get();
            Element quoteElement = doc.select(".quote").first();
            String realId = quoteElement.select("b").first().text();
            if(realId.equals("#???")) return null;
            String text = quoteElement.select(".quotbody").first().text();
            return new AbstractMap.SimpleEntry<>(Integer.parseInt(realId.substring(1)), text);
        }catch (IOException e){
            e.printStackTrace();
        }
        return null;

    }
}
