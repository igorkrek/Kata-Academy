import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FinalWithResources {


    /*Пользователь вводит 5 названий файлов. Они могут повторяться.
    Сохраните в каждый из файл названия ВСЕХ 5 файлов,
    используйте try with resources
      */

    public FinalWithResources() {

        String[] arrayNameFile = new String[5];
        try {
            Scanner scanner = new Scanner(System.in);

            for (int i = 0; i < 5; i++) {
                System.out.println("Введите имя файла " + i + ":");
                arrayNameFile[i] = scanner.nextLine() + ".txt";
                File file = new File(arrayNameFile[i]);
            }
        } catch (Exception e) {
            System.err.println(" ошибка ввода");
        }


        for (String m : arrayNameFile) {
            File file = new File(m);
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
                for (String n : arrayNameFile) {
                    writer.write(n);

                }
                writer.close();

            } catch (IOException e) {
                System.err.println(" ошибка " + e);
            }

        }

    }
}
