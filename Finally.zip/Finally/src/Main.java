public class Main {
    public static void main(String[] args) {

        OperatorFinally final_ = new  OperatorFinally();
        FinalWithResources FinalWithResources = new FinalWithResources();
    }
}