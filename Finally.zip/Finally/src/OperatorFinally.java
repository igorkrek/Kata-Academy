import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;


    public class OperatorFinally {

    /*2.Пользователь вводит 5 названий файлов.
    Сохраните в каждый из файл названия ВСЕХ 5 файлов,
    используйте try.. catch..finally
    */

        public OperatorFinally () {
            try {
                Scanner scanner = new Scanner(System.in);
                String[] arrayNameFile = new String[5];
                for (int i = 0; i < 5; i++) {
                    System.out.println("Введите имя файла " + i + ":");
                    arrayNameFile[i] = scanner.nextLine() + ".txt";
                    File file = new File(arrayNameFile[i]);

                }
                for (String m : arrayNameFile) {
                    File file = new File(m);
                    BufferedWriter writer = new BufferedWriter(new FileWriter(file));
                    for (String n : arrayNameFile) {
                        writer.write(n);

                    }
                    writer.close();
                }
            } catch (IOException e) {
                System.err.println(" ошибка " + e);

            } finally {
                System.out.println(" программа завершена ");
            }

        }

    }

