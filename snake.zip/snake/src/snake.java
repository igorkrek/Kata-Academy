public class snake {

    int sizesnake = 3, countA=10;


    int[][] snake = new int[20][2];//координаты змеи

    public void initSnake(String[][] s) {
        this.snake[0][0] = 0;
        this.snake[0][1] = 0;
        this.snake[1][0] = 0;
        this.snake[1][1] = 1;
        this.snake[2][0] = 0;
        this.snake[2][1] = 2;
        printSnake(s);
    }

    public void printSnake(String[][] s) {
        for (int i = 0; i < sizesnake; i++) {
            s[this.snake[i][0]][this.snake[i][1]] = " S ";
        }

    }
        public void snakeTurn (String[][]s,char a){

            s[this.snake[0][0]][this.snake[0][1]] = " . ";
                for (int i=0;i<sizesnake-1;i++){
                    this.snake[i][0]=this.snake[i+1][0];
                    this.snake[i][1]=this.snake[i+1][1];}
                switch (a){
                    case'6': this.snake[sizesnake-1][1]=this.snake[sizesnake-1][1]+1;break;
                    case'2': this.snake[sizesnake-1][0]=this.snake[sizesnake-1][0]+1;break;
                    case'4': this.snake[sizesnake-1][1]=this.snake[sizesnake-1][1]-1;break;
                    case'8': this.snake[sizesnake-1][0]=this.snake[sizesnake-1][0]-1;break;
                    default: this.snake[sizesnake-1][1]=this.snake[sizesnake-1][1];break;}
                if (this.snake[sizesnake-1][1]>19){this.snake[sizesnake-1][1]=0;System.out.println("Внимание!Телепортация!");}
                if (this.snake[sizesnake-1][1]<0){this.snake[sizesnake-1][1]=19;System.out.println("Внимание!Телепортация!");}
                if (this.snake[sizesnake-1][0]>19){this.snake[sizesnake-1][0]=0;System.out.println("Внимание!Телепортация!");}
                if (this.snake[sizesnake-1][0]<0){this.snake[sizesnake-1][0]=19;System.out.println("Внимание!Телепортация!");}

        }
    public int gamecontrol(String[][] s, int count) {
        if (s[this.snake[sizesnake-1][0]][this.snake[sizesnake-1][1]].contains("S")) {count=-3000;};
        if (s[this.snake[sizesnake-1][0]][this.snake[sizesnake-1][1]].contains("W")) {count=-2000;};
        if (s[this.snake[sizesnake-1][0]][this.snake[sizesnake-1][1]].contains("*")) {count+=200;this.countA--;this.sizesnake++;this.snake[sizesnake-1][0]=this.snake[sizesnake-2][0];this.snake[sizesnake-1][1]=this.snake[sizesnake-2][1];System.out.println("Ура! Нашел яблоко! осталось - "+countA);};
        if (countA==0){count=count-1000;}
        printSnake(s);
return count;



    }
}