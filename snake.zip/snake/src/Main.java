import java.util.Scanner;
public class Main {


    public static void main(String[] args) {
        System.out.println("Hello snake!");
        System.out.println("Тебе нужно собрать все яблоки -'*', при этом не врезаться в стены - 'W'! Вверх-'8', вниз-'2', вправо-'6',влево-'4'. ");
        Scanner scan = new Scanner(System.in);
        field f = new field();
        snake s = new snake();
        int count = 200;
        f.fieldInitialize();
        f.appWall();
        s.initSnake(f.field);
        f.fieldPrinter();
       while (count > 1){  char a = scan.nextLine().charAt(0);
            s.snakeTurn(f.field, a);
            count = s.gamecontrol(f.field, count) - 10;
            f.fieldPrinter();
            if (count>=0){System.out.println("счет: " + count);}
        }
        if (count == -2010) {System.out.println("Game over! Врезался в стену!"+ count);}
        if (count == -3010) {System.out.println("Game over! Сожрал сам себя!"+count);}
        if (count < 0 & count>-1000) {System.out.println("Game over! Молодец!Сожрал все яблоки! Счет: "+(count+1000));}
        if (count == 0) {System.out.println("Game over! Долго шел!");}
    }
}