import java.util.Random;

public class field {
    String[][] field = new String[20][20];

    public void fieldPrinter() {
        for (int i = 0; i < 20; i++) {
            for (int j = 0; j < 20; j++) {
                System.out.print(this.field[i][j]);
            }
            System.out.println();
        }
    }

    public void fieldInitialize() {
        for (int i = 0; i < 20; i++) {
            for (int j = 0; j < 20; j++) {
                this.field[i][j] = " . ";
            }
        }
    }

    public void appWall() {
        Random random = new Random();
        random.nextInt(20);
        for (int i = 0; i <=9; i++) {
            this.field[random.nextInt(20)][random.nextInt(20)] = " * ";
        }
        for (int j = 0; j < 60; j++) {
            int x=random.nextInt(20); int y=random.nextInt(20);
           if (!this.field[x][y].contains("*")){ this.field[x][y]= " W ";};



        }
    }
}



