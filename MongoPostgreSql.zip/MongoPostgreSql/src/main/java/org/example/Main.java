package org.example;

import connects.MongoDb;
import connects.PostgreSql;
import models.User;

import java.sql.SQLException;
import java.util.Map;

public class Main {
    public static void main(String[] args) throws SQLException {


        PostgreSql postgreSql = new PostgreSql();
        postgreSql.connect();
        postgreSql.insertToTable();

        MongoDb mongoDb = new MongoDb();
        mongoDb.mdb(postgreSql.extractFromPsql());
    }
}


