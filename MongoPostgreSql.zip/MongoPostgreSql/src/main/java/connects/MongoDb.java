package connects;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.mongodb.client.MongoClients;
import models.User;
import org.bson.Document;
import java.util.Map;
import java.util.function.Consumer;


public class MongoDb {
    public void mdb(Map<String, User> bag){
     try (var mongoClient = MongoClients.create("mongodb://localhost:27017")) {

        mongoClient.listDatabases().forEach((Consumer<Document>) System.out::println);
        mongoClient.listDatabaseNames().forEach((Consumer<String>) System.out::println);

        var database = mongoClient.getDatabase("syn");
        var todoCollection = database.getCollection("User");
        database.listCollectionNames().forEach((Consumer<String>) System.out::println);
        // User
        database.listCollections().forEach((Consumer<Document>) System.out::println);

         //Set pretty printing of json
         ObjectMapper objectMapper = new ObjectMapper();
         objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
         //Convert Map to JSON
         String mapToJson = objectMapper.writeValueAsString(bag);
         System.out.println("MongoDB:");

         todoCollection.insertOne(Document.parse(mapToJson));
         todoCollection.find()
                .forEach((Consumer<Document>) System.out::println);
         System.out.println(mapToJson);
    } catch (JsonProcessingException e) {
         throw new RuntimeException(e);
     }
    }
}
