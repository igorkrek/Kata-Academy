package connects;

import models.User;

import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class PostgreSql {
    Connection conn = null;
    String url = "jdbc:postgresql://localhost:5432/postgres";
    String user = "igor";
    String password = "1234";
    public Connection connect() throws SQLException {
        conn = DriverManager.getConnection(url, user, password);
            conn.createStatement().execute("create table IF NOT EXISTS \"Users\" \n" +
                    "(id INT GENERATED ALWAYS AS IDENTITY, \n" +
                    "name VARCHAR(20) not null,\n" +
                    "phone VARCHAR(15),\n" +
                    "email VARCHAR(100),\n" +
                    " PRIMARY KEY (id)\n" +
                    ");");

       return conn;
}
public Map<String, User> extractFromPsql() throws SQLException {
       String sql = "select * from \"Users\" ";

    Map<String,User>  bag = new HashMap<>();
       Connection conn = this.connect();
       Statement stmt = conn.createStatement();
       ResultSet rs = stmt.executeQuery(sql);

       while (rs.next()){
           User user = new User(rs.getString("id"),
                   rs.getString("name"),
                   rs.getString("phone"),
                   rs.getString("email"));
            bag.put(rs.getString("id"), user);
           System.out.println("id = " + rs.getString("id")
                  + " name:" + rs.getString("name")
                  + " phone:" + rs.getString("phone")
                   + " email:" + rs.getString("email"));

       }
       return bag;
}
        public void insertToTable () throws SQLException {
            conn = DriverManager.getConnection(url, user, password);
             Statement statement = conn.createStatement();
             int rows = statement.executeUpdate("INSERT INTO \"Users\" (name, phone, email) VALUES ('Vlad', '+7993223456', 'wjrweorweoi@ya.ru');");
                System.out.printf("PostgreSQL: Added %d rows.", rows);
            }
   }

