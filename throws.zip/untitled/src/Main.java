import java.io.File;
import java.io.IOException;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws DatePeriodException, IOException {
       System.out.println("Hello!" +
               "Доработайте крестики-нолики; создайте исключение, которое будете бросать при неверном вводе пользовател");
//        crossnull x = new crossnull();

//        System.out.println("Доработайте калькулятор: при неверном вводе выбрасывайте исключение");
//        calculator calculator=new calculator();

//        System.out.println("Аналогичным образом, доработайте запрос курса валют на дату: " +
//                "при некорректном вводе бросайте исключение. При отсутствии курса валют в ответе, " +
//                "бросайте другое исключение");
//        DatePeriod dp=new DatePeriod();
//        dp.DatePeriod();

        System.out.println("Создайте 10 классов-исключений. Соберите их в массив. " +
                "Пусть пользователь выбирает, какое по счету исключение выбросить");

        IOException [] e=new IOException[11];
            e[1]= new oneException();
            e[2]= new twoException();
            e[3]= new threeException();
            e[4]= new fourException();
            e[5]= new fiveException();
            e[6]= new sixException();
            e[7]= new sevenException();
            e[8]= new eightException();
            e[9]= new nineException();
            e[10]= new tenException();

//            System.out.println("Введите число, кроме 0: ");
                Scanner scan= new Scanner(System.in);
//                    int x=scan.nextInt();
//                    if (x==0){  System.out.println("Выберете исключение: ");
//                        x = scan.nextInt(); throw e[x];
//                    }
//        System.out.println(" Соберите их в матрицу 3х3. " +
//                "Пусть пользователь выбирает номер столбца и строки, какое выбросить исключение." +
//                " Если ввод неверный -выбросите десятоe.");
//        IOException [][] exceptions=new IOException[3][3];
//        for (int i=0;i<3;i++){
//            for (int j=0;j<3;j++){
//                exceptions[i][j]=e[i+j];
//            }
//        }
//        System.out.println("Выберете исключение: ");
//        System.out.println("Введите номер строки: ");
//        int i=scan.nextInt();
//        System.out.println("Введите номер столбца: ");
//        int j=scan.nextInt();
//        if (i<0||i>2||j<0||j>2){ throw e[10];}
//        if (i>=0||i<3||j>=0||j<3){ throw exceptions [i][j];}


        System.out.println("Сделайте функцию, которая возвращает случайное исключение из этих 10 " +
                "(тип возвращаемого значения будет общий: Exception). Выбросите это случайное исключение");
        Random random=new Random();
        int ran = random.nextInt(10);
            throw e[ran];








    }
}