import java.io.IOException;

public class sevenException  extends IOException {
    public sevenException (){
        super("седьмое исключение");
    }
}

