import java.util.Scanner;

public class calculator {
    public calculator() {
        System.out.println("Сделать калькулятор для трех чисел: пользователь вводит первое, потом оператор, второе, оператор, третье. Посчитать первое на второе, потом результат с третьим. Пример:11+4*20Вывод: 300");
        Scanner scan = new Scanner(System.in);
        System.out.println("Введите 1 число:");
        double a3 = scan.nextDouble();
        System.out.println("+,-,*,/");
        String d = scan.next();
        if (!"+,-,*,/".contains(d)) {
            throw new RuntimeException("ошибка введени операции");}
            System.out.println("Введите 2 число:");
            double b3 = scan.nextDouble();
            double s = 0;
            switch (d) {
                case "+":
                    s = a3 + b3;
                    break;
                case "-":
                    s = a3 - b3;
                    break;
                case "*":
                    s = a3 * b3;
                    break;
                case "/":
                    s = a3 / b3;
                    break;

            }

            System.out.println("+,-,*,/");
            String d1 = scan.next();
            if (!"+,-,*,/".contains(d1)) {
                throw new RuntimeException("ошибка введени операции");}
                System.out.println("Введите 3 число:");
                int c3 = scan.nextInt();
                switch (d1) {
                    case "+":
                        System.out.println(s + c3);
                        break;
                    case "-":
                        System.out.println(s - c3);
                        break;
                    case "*":
                        System.out.println(s * c3);
                        break;
                    case "/":
                        System.out.println(s / c3);
                        break;
                }
                System.out.println("Решить предыдущую задачу, но операции считать по приоритету (умножение и деление выше сложения вычитания).");
                System.out.println("Введите 1 число:");
                double a4 = scan.nextDouble();
                System.out.println("+,-,*,/");
                String d4 = scan.next();
                if (!"+,-,*,/".contains(d4)) {
                    throw new RuntimeException("ошибка введени операции");
                }
                System.out.println("Введите 2 число:");
                double b4 = scan.nextDouble();
                System.out.println("+,-,*,/");
                String dd4 = scan.next();
                if (!"+,-,*,/".contains(dd4)) {
                    throw new RuntimeException("ошибка введени операции");
                }
                System.out.println("Введите 3 число:");
                int c4 = scan.nextInt();
                switch (d4 + dd4) {
                    case "++":
                        System.out.println(a4 + b4 + c4);
                        break;
                    case "+-":
                        System.out.println(a4 + b4 - c4);
                        break;
                    case "+*":
                        System.out.println(a4 + b4 * c4);
                        break;
                    case "+/":
                        System.out.println(a4 + b4 / c4);
                        break;
                    case "-+":
                        System.out.println(a4 - b4 + c4);
                        break;
                    case "--":
                        System.out.println(a4 - b4 - c4);
                        break;
                    case "-*":
                        System.out.println(a4 - b4 * c4);
                        break;
                    case "-/":
                        System.out.println(a4 - b4 / c4);
                        break;
                    case "*+":
                        System.out.println(a4 * b4 + c4);
                        break;
                    case "*-":
                        System.out.println(a4 * b4 - c4);
                        break;
                    case "**":
                        System.out.println(a4 * b4 * c4);
                        break;
                    case "*/":
                        System.out.println(a4 * b4 / c4);
                        break;
                    case "/+":
                        System.out.println(a4 / b4 + c4);
                        break;
                    case "/-":
                        System.out.println(a4 / b4 - c4);
                        break;
                    case "/*":
                        System.out.println(a4 / b4 * c4);
                        break;
                    case "//":
                        System.out.println(a4 / b4 / c4);
                        break;
                }
            }
        }

