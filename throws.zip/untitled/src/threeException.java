import java.io.IOException;

public class threeException extends IOException{
    public threeException (){

        super("третье исключение");
        }
    }


