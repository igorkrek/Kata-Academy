import java.io.IOException;

    public class twoException extends IOException {
    public twoException (){
        super("второе исключение");
    }
}

