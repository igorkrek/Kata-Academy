import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class rubRate {

        public void rubRate(LocalDate dataBegin, LocalDate dataEnd) throws DatePeriodException {
            System.out.println("Пользователь вводит месяц и год. " +
                    "Вывести курс рубля за этот месяц, найти наибольший и наименьшие значения");
            //ввод даты
            String date = dataBegin.format(DateTimeFormatter.ofPattern("dd/MM/uuuu"));
            System.out.println("дата:"+date);
            System.out.println("Курс рубля: ");
            float rate = 0;
            //скачивание информации, поиск RUB
            for (LocalDate d= dataBegin;!d.equals(dataEnd); d=d.plusDays(1)) {
                date = d.format(DateTimeFormatter.ofPattern("dd/MM/uuuu"));
                try {
                    rate =  Float.parseFloat(course(date));
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                System.out.println(date+" - "+rate);
            }
        }
        public static String course(String date) throws IOException {
            String result = downloadWebPage("http://www.cbr.ru/scripts/XML_daily.asp?date_req=" + date);
            int start = result.indexOf("<Value>", result.indexOf("USD")) + 7;
            int end = result.indexOf("</Value>", start);
            return result.substring(start, end).replace(',','.');
        }
        //метод скачивания API
        private static String downloadWebPage(String url) throws IOException {
            StringBuilder result = new StringBuilder();
            String line;
            URLConnection urlConnection = new URL(url).openConnection();
            try (InputStream is = urlConnection.getInputStream();
                 BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
                while ((line = br.readLine()) != null) {
                    result.append(line);
                }
            }
            return result.toString();
        }
    }




