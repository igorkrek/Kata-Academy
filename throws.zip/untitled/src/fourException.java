import java.io.IOException;

public class fourException extends IOException {
          public fourException (){

              super("четвертое исключение");
        }
    }


