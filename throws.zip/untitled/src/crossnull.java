import java.util.Scanner;

public class crossnull {
        private boolean stop;

        public  crossnull() {
            String field = " 1 2 3\n " +
                    "4 5 6\n" +
                    " 7 8 9\n";
            StringBuilder sb = new StringBuilder(field);
            System.out.println(sb);
            int step, delta = 0; String symbol;
            StringBuilder gamerO = new StringBuilder();
            StringBuilder gamerX = new StringBuilder();
            Scanner scan = new Scanner(System.in);
            for (int i = 0; i < 4; i++) {
                System.out.println("Игрок 'X' набери номер позиции:");
                step = scan.nextInt();
                if (step<1 || step>9){
                    throw new RuntimeException("введен неверный символ");}
                symbol="X";
                gamerX.append(step);
                if (step >= 1 & step <= 3) {
                    delta = 0;
                }
                ;
                if (step >= 4 & step <= 6) {
                    delta = 1;
                }
                if (step >= 7) {
                    delta = 2;
                }
                crossnullException cne= new crossnullException(sb.substring(step * 2 - 1 + delta,step * 2 + delta));

                sb.replace(step * 2 - 1 + delta, step * 2 + delta, "X");
                System.out.println(sb);
                control(gamerX,symbol);if(stop){break;}

                System.out.println("Игрок '0' набери номер позиции:");
                step = scan.nextInt();
                gamerO.append(step);symbol="O";
                if (step >= 1 & step <= 3) {
                    delta = 0;
                }
                ;
                if (step >= 4 & step <= 6) {
                    delta = 1;
                }
                if (step >= 7) {
                    delta = 2;
                }

               cne= new crossnullException(sb.substring(step * 2 - 1 + delta,step * 2 + delta));
                sb.replace(step * 2 - 1 + delta, step * 2 + delta, "0");
                System.out.println(sb);
                control(gamerO,symbol);if(stop){break;}
            }

            System.out.println("Игрок 'X' набери номер позиции:");
            step = scan.nextInt();symbol="X";
            gamerX.append(step);
            if (step >= 1 & step <= 3) {
                delta = 0;
            }
            ;
            if (step >= 4 & step <= 6) {
                delta = 1;
            }
            if (step >= 7) {
                delta = 2;
            }
            sb.replace(step * 2 - 1 + delta, step * 2 + delta, "X");
            System.out.println(sb);
            control(gamerX,symbol);


            if(!stop){System.out.println("ничья!");}
        }
        public void control(StringBuilder sb,String symbol) {
            if ((sb.toString().contains("1") & sb.toString().contains("2") & sb.toString().contains("3"))|
                    (sb.toString().contains("1") & sb.toString().contains("5") & sb.toString().contains("9"))|
                    (sb.toString().contains("3") & sb.toString().contains("5") & sb.toString().contains("7"))|
                    (sb.toString().contains("4") & sb.toString().contains("5") & sb.toString().contains("6"))|
                    (sb.toString().contains("7") & sb.toString().contains("8") & sb.toString().contains("9"))|
                    (sb.toString().contains("2") & sb.toString().contains("5") & sb.toString().contains("8"))|
                    (sb.toString().contains("3") & sb.toString().contains("6") & sb.toString().contains("9")))
            { System.out.println("Игрок "+symbol+" победил!");this.stop=true; }
        }
    }



