import java.io.IOException;

public class sixException extends IOException {
    public sixException (){
        super("шестое исключение ");
    }
}

