public class crossnullException extends Exception {
    public crossnullException(String step) {
        if (step.contains("X") ||
                step.contains("0")) {
            throw new RuntimeException("Неверный ход! позиция занята!");
        }

    }
}