import java.io.IOException;

public class fiveException extends IOException {
            public fiveException (){

                super("пятое исключение");
        }
    }



