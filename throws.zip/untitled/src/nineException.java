import java.io.IOException;

public class nineException  extends IOException {
    public nineException (){
        super("девятое исключение");
    }
}


