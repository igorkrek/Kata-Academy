import java.io.IOException;

public class eightException extends IOException {
    public eightException (){
        super("восьмое исключение");
    }
}

