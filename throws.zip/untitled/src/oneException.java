import java.io.IOException;

public class oneException extends IOException {
    public oneException (){
        super("первое исключение");
    }
}
