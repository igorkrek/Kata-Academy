import java.io.IOException;

public class tenException  extends IOException {
    public tenException (){
        super("десятое исключение");
    }
}

