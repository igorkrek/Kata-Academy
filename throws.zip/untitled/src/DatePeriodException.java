public class DatePeriodException extends Exception{
    public DatePeriodException (){

        super("Че то не то!");
    }
}
