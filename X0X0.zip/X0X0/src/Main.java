public class Main {
    public static void main(String[] args) {
        System.out.println("Hello!");
        X0X0 x = new X0X0();
        x.X0X0();
    }
}