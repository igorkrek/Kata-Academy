import java.util.Scanner;



    public class X0X0 {
        private boolean stop;

        public void X0X0() {
            String f = " 1 2 3\n " +
                    "4 5 6\n" +
                    " 7 8 9\n";
            StringBuilder sb = new StringBuilder(f);
            System.out.println(sb);
            int x, delta = 0; String g;
            StringBuilder gamerO = new StringBuilder();
            StringBuilder gamerX = new StringBuilder();
            Scanner scan = new Scanner(System.in);
            for (int i = 0; i < 4; i++) {
                System.out.println("Игрок 'X' набери номер позиции:");
                x = scan.nextInt();g="X";
                gamerX.append(x);
                if (x >= 1 & x <= 3) {
                    delta = 0;
                }
                ;
                if (x >= 4 & x <= 6) {
                    delta = 1;
                }
                if (x >= 7) {
                    delta = 2;
                }
                sb.replace(x * 2 - 1 + delta, x * 2 + delta, "X");
                System.out.println(sb);
                control(gamerX,g);if(stop){break;}

                System.out.println("Игрок '0' набери номер позиции:");
                x = scan.nextInt();
                gamerO.append(x);g="O";
                if (x >= 1 & x <= 3) {
                    delta = 0;
                }
                ;
                if (x >= 4 & x <= 6) {
                    delta = 1;
                }
                if (x >= 7) {
                    delta = 2;
                }
                sb.replace(x * 2 - 1 + delta, x * 2 + delta, "0");
                System.out.println(sb);
                control(gamerO,g);if(stop){break;}
            }

            System.out.println("Игрок 'X' набери номер позиции:");
            x = scan.nextInt();g="X";
            gamerX.append(x);
            if (x >= 1 & x <= 3) {
                delta = 0;
            }
            ;
            if (x >= 4 & x <= 6) {
                delta = 1;
            }
            if (x >= 7) {
                delta = 2;
            }
            sb.replace(x * 2 - 1 + delta, x * 2 + delta, "X");
            System.out.println(sb);
            control(gamerX,g);


            if(!stop){System.out.println("ничья!");}
        }
        public void control(StringBuilder sb,String g) {
            if ((sb.toString().contains("1") & sb.toString().contains("2") & sb.toString().contains("3"))|
                    (sb.toString().contains("1") & sb.toString().contains("5") & sb.toString().contains("9"))|
                    (sb.toString().contains("3") & sb.toString().contains("5") & sb.toString().contains("7"))|
                    (sb.toString().contains("4") & sb.toString().contains("5") & sb.toString().contains("6"))|
                    (sb.toString().contains("7") & sb.toString().contains("8") & sb.toString().contains("9"))|
                    (sb.toString().contains("2") & sb.toString().contains("5") & sb.toString().contains("8"))|
                    (sb.toString().contains("3") & sb.toString().contains("6") & sb.toString().contains("9")))
            { System.out.println("Игрок "+g+" победил!");this.stop=true; }
        }
    }


