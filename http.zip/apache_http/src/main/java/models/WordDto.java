package models;

public class WordDto {
    String text;
    String reference;

    public WordDto(String text, String reference) {
        this.text = text;
        this.reference = reference;
    }

    @Override
    public String toString() {
        return "Текст из " + reference + ": " + text;
    }
}