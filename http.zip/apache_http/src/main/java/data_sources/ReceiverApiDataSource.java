package data_sources;

import models.WordDto;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface ReceiverApiDataSource {
    @GET("https://bible-api.com/{book}{chapter}:{verse}")
    Call<WordDto> listRepos(@Path("book") String book,
                            @Path("chapter") String chapter,
                            @Path("verse") String verse);
}

