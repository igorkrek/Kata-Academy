package domain;

import data_sources.ReceiverApiDataSource;
import models.WordDto;
import retrofit2.Call;
import retrofit2.Response;

import java.io.IOException;
import java.util.Scanner;

public class ReceiverService {
    ReceiverApiDataSource receiverApiDataSource;



    public ReceiverService(ReceiverApiDataSource receiverApiDataSource) {
        this.receiverApiDataSource = receiverApiDataSource;
    }

    public String fetch(String chapter, String verse) {
        Call<WordDto> repos = receiverApiDataSource.listRepos("john", chapter, verse);
        Response<WordDto> res = null;
        try {
            res = repos.execute();
            System.out.println("Состояние: " + repos.isExecuted());
        } catch (
                IOException e) {
            throw new RuntimeException(e);
        }
        System.out.println(res.body().toString());
        return res.body().toString();
    }

    public void fetchAll() {
        int verses = 5;
        System.out.println("введите главу: ");
        Scanner scan = new Scanner(System.in);
        String chapter = scan.next();
        System.out.println("введите начальный стих: ");
        int verse = scan.nextInt();

    for (int i = verse; i < verses + verse; i++){

        System.out.println(i);
        fetch(chapter, String.valueOf(i));

     }
    }
}