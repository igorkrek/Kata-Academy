/*
Получение стихов из Библии, книги "Евангелие от Иоанна" по номеру главы и номеру стиха.



 */


package org.example;
import com.google.gson.Gson;
import data_sources.ReceiverApiDataSource;
import domain.ReceiverService;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;




public class Main {
    public static void main(String[] args) {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://bible-api.com/")
                .addConverterFactory(GsonConverterFactory.create(new Gson()))
                .build();
        ReceiverApiDataSource receiverApiDataSource = retrofit.create(ReceiverApiDataSource.class);
        ReceiverService receiverService = new ReceiverService(receiverApiDataSource);

        receiverService.fetchAll();
    }
}

