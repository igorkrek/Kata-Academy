import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Main {

    public static void main(String[] args) throws IOException {
        System.out.println("Сделайте класс для цитаты из breaking bad: " +
                "цитата и автор. Сохраните в массив таких классов 10 цитат");

        String path = "C:/Users/user/Desktop/BBquotes/";// создание каталога
        Files.createDirectory(Paths.get(path));
        String quotes = "https://bbf.ru/quotes/source/78137/";
        quotes = downloadWebPage (quotes);
        String a;
        String autor;
        int urlBegin=0;
        int urlEnd=0;

        System.out.println(quotes);
        for (int i = 0; i < 10; i++) {
            File file = new File("C:/Users/user/Desktop/BBquotes/bbquote" + i + ".java");//cоздание класса
            FileOutputStream fos = new FileOutputStream(file);
            urlBegin = quotes.indexOf("<p>",urlBegin+1);
            urlEnd = quotes.indexOf("</p> ",urlEnd+1);
            String quote = quotes.substring(urlBegin+3, urlEnd);
            System.out.println(quote);//цитата
            urlBegin = quotes.indexOf("/quotes/character/",urlEnd+1);
            urlEnd = quotes.indexOf("</a> ",urlEnd+1);
            autor = quotes.substring(urlBegin+27, urlEnd);
            System.out.println(autor);//автор
            a = "public class quote" + i + " {\n" +
                    "\n" +
                    "        public static void main(String[] args) {" +
                    "" +
                    " String quote='";
            fos.write(a.getBytes());
            fos.write(quote.getBytes());
            fos.write(autor.getBytes());
            a = "'}}";
            fos.write(a.getBytes());
            fos.close();
        }
    }
        //метод скачивания API
        private static String downloadWebPage (String url) throws IOException {
            StringBuilder result = new StringBuilder();
            String line;
            URLConnection urlConnection = new URL(url).openConnection();
            try (InputStream is = urlConnection.getInputStream();
                 BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
                while ((line = br.readLine()) != null) {
                    result.append(line);
                }
            }
            return result.toString();
        }
    }






