/*
Для  действий с визуалом. Реализует конструктор - название действия и  массив  действий.
 */

import InternetShop.Product;

import java.util.ArrayList;
import java.util.Comparator;

public  class AppView {

    public final String tittle;
    public  final ArrayList<AppView> children;
    public  int nowPage = 0;

    public  boolean hasNextPage = false;
    public ArrayList<AppComparator<Product>> availabelComparator = new ArrayList<>();
    public AppComparator<Product> selectedComparator;

    public AppView(String tittle, ArrayList<AppView> children) {
        this.tittle = tittle;
        this.children = children;
        if (!availabelComparator.isEmpty()){
            selectedComparator = availabelComparator.get(0);
        }

    }
     public void action(){
    }

}
