public interface Paginable {
    public  int pageLimit = 5;
}
