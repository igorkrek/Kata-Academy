/*добавление в корзину и получение данных козины. Абстрактный шаблон

 */
package InternetShop;

import java.util.ArrayList;

public abstract class CartDataSource {


    public abstract void addToCart(Product product, int count);
    public abstract ArrayList<CartItem> getCart();


}