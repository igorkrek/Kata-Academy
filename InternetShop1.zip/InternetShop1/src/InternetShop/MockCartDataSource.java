/*
Реализация абстрактного шаблона CartDataSource. Добавление в корзину и получение инфо корзины
 */

package InternetShop;
import java.util.ArrayList;

public class MockCartDataSource extends CartDataSource {
    private ArrayList<CartItem> cart = new ArrayList<>();

    @Override
   public void addToCart(Product product, int count) {

        cart.add(new CartItem(product, count));
    }
    @Override
   public ArrayList<CartItem> getCart() {

        return cart;
    }
}
