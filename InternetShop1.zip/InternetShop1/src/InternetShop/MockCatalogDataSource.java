/*
Реализация абстрaктного шаблона CatalogDataSource. Получение данных каталога.
 */

package InternetShop;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;


public class MockCatalogDataSource extends CatalogDataSource {

    @Override
    public ArrayList<Product> getCatalog(int page, int limit, Comparator<Product> comparator) {
        ArrayList<Product> products = generateProduct();
        products = new ArrayList<>(products.stream().filter(x -> x.availabel).sorted(comparator).skip((long) page * limit).limit(limit).collect(Collectors.toList()));
        return products;
    }

    @Override
    public ArrayList<Product> getCatalog(int page, int limit) {
        ArrayList<Product> products = generateProduct();
      products = new ArrayList<>(products.stream().filter(x -> x.availabel).skip((long) page * limit).limit(limit).collect(Collectors.toList()));
        return products;
    }

    public Product productById (String id){
        ArrayList<Product> products = getCatalog(0,999);
        for (Product p:products){
            if (p.id.equals(id)){
                return p;
            }
        }
        return null;
    }
    public ArrayList<Product> generateProduct(){
            ArrayList<Product> products = new ArrayList<>();
        products.add(new Product("id1", "Smart Phone", "BestPhone", 1000, true));
        products.add(new Product("id2", "Laptop", "Best laptop", 2000, true));
        products.add(new Product("id3", "Watch", "Best watch", 500, true));
        products.add(new Product("id4", "Phone", "Simple Phone", 1000, true));
        for(int i = 0; i < 20; i++){
            products.add(new Product("id" + (i + 5), "Phone" + i, "Samsung", i * 100, i / 4 != 0));
        }

return products;
    }



}