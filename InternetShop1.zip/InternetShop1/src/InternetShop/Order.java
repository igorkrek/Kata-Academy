/*
Инфо о клиенте и заказе
 */

package InternetShop;

import java.util.ArrayList;


public class Order {
   public String Name;
   public String phone;
   public String address;
   public String paymentType;
   public String deliveryTime;
   public ArrayList<CartItem> cart;

    public Order(String Name, String phone, String address, String paymentType, String deliveryTime, ArrayList<CartItem> cart) {
        this.Name = Name;
        this.phone = phone;
        this.address = address;
        this.paymentType = paymentType;
        this.deliveryTime = deliveryTime;
        this.cart = cart;

    }
}