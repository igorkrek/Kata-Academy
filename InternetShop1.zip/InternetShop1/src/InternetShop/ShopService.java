/*
Абстрактный шаблон, объединяющий все три абстрактных шаблона - заказ, каталог и корзина с прописыванием методов:
1.получения каталога, 2.Добавление в корзину, 3.Просмотр корзины, 4.Оформление заказа, 5.Просмотр заказа.
Т.е. Это общий абстрактный шаблон без конкретной реализации работы с клиентом.
 */

package InternetShop;
import java.util.ArrayList;
import java.util.Comparator;

public class ShopService {

     CartDataSource cartDataSource;
     OrderDataSource orderDataSource;
     CatalogDataSource catalogDataSource;


    public ShopService(CartDataSource cartDataSource, OrderDataSource orderDataSource, CatalogDataSource catalogDataSource) {
        this.cartDataSource = cartDataSource;
        this.orderDataSource = orderDataSource;
        this.catalogDataSource = catalogDataSource;
    }

    public ArrayList<Product> getCatalog(int page, int limit){

        return catalogDataSource.getCatalog(page, limit);
    }
    public ArrayList<Product> getCatalog(int page, int limit, Comparator<Product> comparator){

        return catalogDataSource.getCatalog(page, limit, comparator);
    }


    public boolean addToCart(String productId, int count){
    Product product = catalogDataSource.productById(productId);

        if (product != null){
            cartDataSource.addToCart(product, count);
            return  true;
        }

     return  false;
    }
    public ArrayList<CartItem> getCart(){
        return cartDataSource.getCart();
    }
    public void createOrder(String Name, String phone, String address, String paymentType, String deliveryTime){

        ArrayList<CartItem> cart = getCart();
        Order newOrder = new Order(Name, phone, address, paymentType, deliveryTime, cart);
        orderDataSource.createOrder(newOrder);


    }
    public void getOrder(){
       System.out.println(orderDataSource.getOrder().Name + " / " + orderDataSource.getOrder().address +
               " / " + orderDataSource.getOrder().phone +
               " / " + orderDataSource.getOrder().deliveryTime +
               " / " + orderDataSource.getOrder().paymentType + " - заказ оформлен");

    }
}