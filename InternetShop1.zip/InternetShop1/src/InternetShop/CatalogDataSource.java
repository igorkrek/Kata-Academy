/*
Абстрактный шаблон, получение данных каталога
 */

package InternetShop;

import java.util.ArrayList;
import java.util.Comparator;

public abstract class CatalogDataSource  {
    public abstract ArrayList<Product> getCatalog(int page, int limit, Comparator<Product> comparator);// получение каталога
    public abstract ArrayList<Product> getCatalog(int page, int limit);// получение каталога
    public abstract Product productById (String id);
}
