/*
Реализация абстрактного класса OrderDataSource. Создание ордера и получение инфо ордера
 */

package InternetShop;

public class MockOrderDataSource extends OrderDataSource{
    Order order;
    @Override
    public void createOrder(Order order) {

        this.order = order;
    }

    @Override
   public Order getOrder() {

        return order;
    }
}
