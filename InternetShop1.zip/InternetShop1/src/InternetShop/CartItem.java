/* корзина - product и количество. Конструктор.

 */

package InternetShop;

public class CartItem {
    public Product product;
    public int count;

    public CartItem(Product product, int count) {
        this.product = product;
        this.count = count;
    }


}