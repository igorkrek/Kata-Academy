/*
Информация о продукте
 */

package InternetShop;

public class Product {

    public String id;
    public String title;
    String description;
    public int price;
    boolean availabel;

    public Product(String id, String title, String description, int price, boolean availabel) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.price = price;
        this.availabel = availabel;
    }
}