/*
Абстрактный шаблон получения информации заказа и создания заказа.
 */

package InternetShop;

public abstract class OrderDataSource {
    Order order;
    public abstract void createOrder(Order order);
    public abstract  Order getOrder();
}