/*
работа с children
 */
import java.util.Scanner;


public class PageLoop {

    public  int getChildrenSize (){
        return view.children.size();
    }
    public int getOptionalSize(){
        int optionalSize = 0;
        if (view.hasNextPage){ optionalSize++;}
        optionalSize += view.availabelComparator.size();
            return optionalSize;
      }
    public final AppView view;
    public PageLoop(AppView view) {

        this.view = view;
    }
    public void run() {
        while (true) {
            view.action();
            displayChildren();
            final int fullSize = getChildrenSize() + getOptionalSize() +1;
            Scanner in = new Scanner(System.in);
            int value = in.nextInt();
            if (value < 0 || value > fullSize) {
                System.out.println("Неверное значение");
            } else {
                if (value == fullSize){
                    break;
                }else if (value < getChildrenSize()){
                    AppView selectedView = view.children.get(value - 1);
                    new PageLoop(selectedView).run();
                } else {
                    if (value == getChildrenSize() && view.hasNextPage){
                   view.nowPage++;
                    new PageLoop(view).run();
                }else {
                        view.nowPage = 0;
                        int compararatorIndex = value - getChildrenSize() - (view.hasNextPage ? 1:0) - 1;
                        view.selectedComparator = view.availabelComparator.get(compararatorIndex);
                        new PageLoop(view).run();
                    }
                }


            }

        }

    }
    public  void displayChildren (){
        int currentIndex = 1;
        System.out.println(view.tittle);
        System.out.println("выберите вариант от 1 до " + (getChildrenSize() + 1));
        for (int i = 0; i < getChildrenSize(); i++) {
            AppView _view = view.children.get(i);
            System.out.println(currentIndex + " - " + _view.tittle);
            currentIndex++;
        }
        if (view.hasNextPage){
            System.out.println(currentIndex +" - следующая страница");
            currentIndex++;
        }
        for (int i = 0; i < view.availabelComparator.size(); i++){
           System.out.println(currentIndex + " - " + view.availabelComparator.get(i).name);
            currentIndex++;
        }

            System.out.println(getChildrenSize() + getOptionalSize() + 1 + " - Назад.");


    }

    }

