/*
Реализация абстрактного шаблона AppView для визуала работы с программой в части оформления заказа

 */
import InternetShop.ShopService;
import java.util.ArrayList;
import java.util.Scanner;

public class OrderView extends AppView{
    public  final ShopService shopService;
    public OrderView(ShopService shopService) {
        super("Оформление заказа", new ArrayList<>());
        this.shopService = shopService;
    }

    public void action(){
        Scanner in = new Scanner(System.in);
        System.out.println("Введите свое имя");
        String name = in.nextLine();
        System.out.println("Введите свой телефон");
        String phone = in.nextLine();
        System.out.println("Введите адрес");
        String address = in.nextLine();
        System.out.println("Введите тип оплаты (карта, наличные)");
        String paymentType = in.nextLine();
        System.out.println("Введите время доставки");
        String deliveryTime = in.nextLine();
      shopService.createOrder(name, phone, address, paymentType, deliveryTime);
        shopService.getOrder();
    }

}
