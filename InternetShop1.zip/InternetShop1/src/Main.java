import InternetShop.*;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        CartDataSource cartDataSource = new MockCartDataSource();
        CatalogDataSource catalogDataSource = new MockCatalogDataSource();
        OrderDataSource orderDataSource = new MockOrderDataSource();
        ShopService shopService = new ShopService(cartDataSource, orderDataSource, catalogDataSource);

        AppView addToCartView = new AddToCartView(shopService);
        ArrayList<AppView> catalogChildren = new ArrayList<>();
        catalogChildren.add(addToCartView);

        ArrayList<AppComparator<Product>>  catalogComparator = new ArrayList<>();
        catalogComparator.add(new AppComparator<Product>(new PriceComparator(true), "по возрастанию цены"));
        catalogComparator.add(new AppComparator<Product>(new PriceComparator(false), "по убыванию цены"));


        AppView catalogView = new CatalogView(shopService, catalogChildren, catalogComparator);

        AppView cartView = new CartView(shopService);
        AppView orderView = new OrderView(shopService);

        ArrayList<AppView> mainChildren = new ArrayList<>();
        mainChildren.add(catalogView);
        mainChildren.add(cartView);
        mainChildren.add(orderView);

        AppView mainView = new MainView(mainChildren);
        new PageLoop(mainView).run();






//        System.out.println(shopService.getCatalog());
//        System.out.println(shopService.getCart());
//
//        System.out.println(shopService.addToCart(shopService.getCatalog().get(0).id, 5));
//        System.out.println(shopService.addToCart("какой то продукт", 5));
//        System.out.println(shopService.getCart());
    }
}