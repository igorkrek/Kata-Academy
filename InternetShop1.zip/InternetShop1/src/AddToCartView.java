/*
Реализация абстрактного шаблона AppView для визуала работы с программой в части добавления в корзину
 */
import InternetShop.ShopService;

import java.util.ArrayList;
import java.util.Scanner;

public class AddToCartView extends AppView{
    public final ShopService shopService;
    public AddToCartView(ShopService shopService) {
        super("Добавить товар", new ArrayList<>());
        this.shopService = shopService;
    }
        public  void action(){
        System.out.println("Введите id продукта: ");
            Scanner scan =new Scanner(System.in);
            String productId = scan.nextLine();
                if (productId == null) return;
            System.out.println("Введите количество: ");
               int count = scan.nextInt();
                   final boolean res = shopService.addToCart(productId, count);
                if(res){
                    System.out.println("товар добавлен");
                } else {
                    System.out.println("не удалось добавить товар");
                }


        }



}
