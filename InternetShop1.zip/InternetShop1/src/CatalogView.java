/*
Реализация абстрактного шаблона AppView для визуала работы с программой в части просмотра каталога
 */
import InternetShop.Product;
import InternetShop.ShopService;

import java.util.ArrayList;
import java.util.Comparator;

public class CatalogView extends  AppView implements Paginable{
    ShopService shopService;
    public CatalogView(ShopService shopService, ArrayList<AppView> children, ArrayList<AppComparator<Product>> comparators) {
        super("Каталог", children);
        this.shopService = shopService;
        availabelComparator.addAll(comparators);
        if(!availabelComparator.isEmpty()){
            selectedComparator = availabelComparator.get(0);
        }
    }

    public void action(){
        PriceComparator comparator = new PriceComparator();
        comparator.isAsk = false;
        ArrayList<Product> catalog = shopService.getCatalog(nowPage, pageLimit, selectedComparator.comparator);
        hasNextPage = catalog.size() == pageLimit;
        for (Product product:catalog){
            System.out.println(product.id + " / " + product.title + " / " + product.price);

        }
        System.out.println();
    }


}
