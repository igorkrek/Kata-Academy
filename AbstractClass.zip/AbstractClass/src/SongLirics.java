import java.io.IOException;


public abstract class SongLirics {



    public abstract String SongName();
    abstract String downloadWebPage (String url) throws IOException;

    abstract  String DetectText (String line);
    }






