import java.io.*;

import java.util.Scanner;

public class DirectorySongLyrics  {

    public DirectorySongLyrics() throws IOException {

        String path = "C:/Users/user/Desktop/СИНЕРГИЯ/kreker_synergy/AbstractClass/src/Songs/";
        SongDetect(SongName(), path);
    }


    public String SongName() {
        System.out.println("Введите название песни для поиска в папке:");
        Scanner scan = new Scanner(System.in);
        String sName = scan.nextLine();
        sName = sName.replaceAll("\\s", "");   //удаление пробелов

        return sName;
    }

    public void SongDetect(String sName, String path) throws IOException {
        String fileName = path + sName + ".txt";


        BufferedReader reader = new BufferedReader(new FileReader(fileName));
        StringBuilder content = new StringBuilder();
        String line;

        while ((line = reader.readLine()) != null) {
            content.append(line);
            content.append(System.lineSeparator());
        }
        line = content.toString();
        line = line.substring(line.indexOf(sName), line.indexOf(";", line.indexOf(sName)));
        System.out.println(line);
    }
}





