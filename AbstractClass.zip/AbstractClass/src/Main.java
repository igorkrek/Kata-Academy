/*1.Создайте абстрактный класс SongLyrics, который возвращает текст песни по названию.
2.Создайте файл в формате: Название песни: текст песни, и так много песен
(можете разделять разные песни пустыми строками, или другим способом)
Создайте наследника -FileSongLyrics, который ищет в файле по названию песни, и если находит,
возвращает текст песни
3.Создайте наследника -DirectorySongLyrics,
который ищет в папке файл с названием песни, и если находит -возвращает текст песни
4.Создайте ApiSongLyrics, который ищет текст песни в этом апи:

https://api.lyrics.ovh/v1/Eminem/Lose%20yourself (ССЫЛКА НЕ РАБОТАЕТ).

Артиста и название песни можно менять. Вместо пробелов вставляйте %20.
5.Создайте метод printLyrics(String artist, String song, SongLyrics songLyrics) -который выводит текст песни.
Вызовите этот метод с наследником по выбору пользователя (из файла, папки или апи)
 */

import java.io.IOException;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) throws IOException {
        int operacion = 1;
            while (operacion != 0) {
                System.out.println("Поиск текстов песен. Выберите:\n" +
                        "1. Искать текст песни в API.\n" +
                        "2. Искать текст песни в файле.\n" +
                        "3. Искать текст песни в папке.\n" +
                                "0. game over");
                Scanner scan = new Scanner(System.in);
                operacion = scan.nextInt();
                switch (operacion) {
                    case 1:
                        TextSongs textSongs = new TextSongs();
                        textSongs.TextSongs();

                        break;
                    case 2:
                        FileSongLyrics fileSongLyrics = new FileSongLyrics();

                        break;
                    case 3:
                        DirectorySongLyrics directorySongLyrics = new DirectorySongLyrics();

                        break;
                    case 0: System.out.println("game over");
                    break;
                }
            }




    }
}