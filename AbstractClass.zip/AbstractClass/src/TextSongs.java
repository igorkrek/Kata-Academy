import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

public class TextSongs extends SongLirics {

    String songName;
    String artistName;

    public void TextSongs() throws IOException {
        String line = SongName();
        line = downloadWebPage(line);
        line = DetectText(line);
        System.out.println(line);
        FileSongs fileSongs = new FileSongs(this.songName,this.artistName, line);
    }

    @Override
    public String DetectText(String line) {
        String text = line.substring(line.indexOf("Sorry about that. -->")+21, line.indexOf("</div><br><br><!--"));
            text = text.replaceAll("<br>", "\n");

            return text;
    }
    @Override
    public String downloadWebPage(String url) throws IOException {
        StringBuilder result = new StringBuilder();
        String line;
        URLConnection urlConnection = new URL(url).openConnection();
        try (InputStream is = urlConnection.getInputStream();
             BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
            while ((line = br.readLine()) != null) {
                result.append(line);
            }
        }
        return result.toString();
    }
    public String SongName(){
        System.out.println("Поиск текстов песен. Введите название песни:");
        Scanner scan = new Scanner(System.in);
        String songName = scan.nextLine();
        System.out.println("Введите исполнителя:");
        String artistName = scan.nextLine();
        songName = songName.replaceAll("\\s", "");
        artistName = artistName.replaceAll("\\s", "");
            this.songName = songName;
            this.artistName = artistName;
        return "https://www.azlyrics.com/lyrics/" + artistName + "/" + songName + ".html";

    }

}
