import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class FileSongs {
    public  FileSongs (String songName, String artistName, String text) throws IOException {

        File file = new File("C:/Users/user/Desktop/СИНЕРГИЯ/kreker_synergy/AbstractClass/src/file.txt");
        BufferedWriter bw = new BufferedWriter(new FileWriter(file, true));
            bw.write("name:" + songName+ "/" + artistName + "\n");
              bw.write(text+";\n");
              bw.close();

        Path path =  Path.of("C:/Users/user/Desktop/СИНЕРГИЯ/kreker_synergy/AbstractClass/src/Songs"); {
        }
        if (!Files.exists(path)) {
            Files.createDirectories(Paths.get("C:/Users/user/Desktop/СИНЕРГИЯ/kreker_synergy/AbstractClass/src/Songs"));
        }
        File fileSong = new File("C:/Users/user/Desktop/СИНЕРГИЯ/kreker_synergy/AbstractClass/src/Songs/" + songName + ".txt");
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(fileSong, true));
        bufferedWriter.write("name:" + songName+ "/" + artistName + "\n");
        bufferedWriter.write(text+";\n");
        bufferedWriter.close();
    }
}
