import java.io.*;
import java.util.Scanner;

public class FileSongLyrics extends TextSongs {

    public FileSongLyrics() throws IOException {

        SongDetect(SongName());
    }

    public String SongName() {
        System.out.println("Введите название песни для поиска в файле:");
        Scanner scan = new Scanner(System.in);
        String songName = scan.nextLine();
        songName = songName.replaceAll("\\s", "");   //удаление пробелов

        return songName;
    }
        public void SongDetect(String songName) throws IOException {
            BufferedReader reader = new BufferedReader(new FileReader("C:/Users/user/Desktop/СИНЕРГИЯ/kreker_synergy/AbstractClass/src/file.txt"));

            StringBuilder content = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                content.append(line);
                content.append(System.lineSeparator());
            }
            line = content.toString();
            line = line.substring(line.indexOf(songName), line.indexOf(";", line.indexOf(songName)));
            System.out.println(line);
        }

 }




