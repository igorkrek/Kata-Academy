import java.io.File;

public class Main {
    public static void main(String[] args) {

        System.out.println("Сохраните информацию о всех файлах в заданной директории в массив FileInformation");

        File path = new File("C:/Users/user/Desktop");
        File[] FileInformation = path.listFiles();
        for (File file : FileInformation) {
            if (file.isFile()) {
                System.out.println(file.getName());
            }
        }




    }
}