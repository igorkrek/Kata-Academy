/*
Задание:

1. Создать класс расширяющий Thread
Создать класс NewThread расширяющий Thread.
Переопределить метод run(). В цикле for вывести на консоль символ 100 раз.
Создать экземпляр класса и запустить новый поток.
2. Создать класс реализующий Runnable
Создать класс, реализующий интерфейс Runnable.
Переопределить run() метод. Создать цикл for. В цикле распечатываем значения от 0 до 100 делящиеся на 10 без остатка.
Используем статический метод Thread.sleep(), чтобы сделать паузу.
Создать три потока, выполняющих задачу распечатки значений.
 */



public class Main {
    public static void main(String[] args) {

        new NewThread().start();

        for (int i = 1; i <= 3; i++) {
             new Thread(new MyThread(new Data(i + " - thread"))).start();


        }
    }
}

class  NewThread extends Thread {

    @Override
    public void run() {
        super.run();
        for (int i = 1; i <= 100; i++){
          System.out.println(i + ": symbol");
        }
    }
}

class Data {
    public Data(String name) {
        this.name = name;
    }

    float volume;
    String name;
        synchronized public boolean process (int volume){
        return volume % 10 == 0;
    }
}
 class MyThread  implements Runnable {
    Data data;

    public MyThread (Data data){
        this.data = data;

    }
    @Override
    public void run() {

        for (int i = 1; i <= 100; i++){

            if (data.process(i)) System.out.println(data.name + " / " + i);
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
}