import java.io.IOException;

public class FinanceCalculatorHtml extends FinanceCalculatorTxt{


    public FinanceCalculatorHtml(String file) throws IOException {
        super(file);
    }


}
