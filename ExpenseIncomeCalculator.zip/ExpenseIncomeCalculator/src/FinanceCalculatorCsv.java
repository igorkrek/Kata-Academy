import java.io.IOException;

public class FinanceCalculatorCsv extends FinanceCalculatorTxt{


  public FinanceCalculatorCsv(String file) throws IOException {
    super(file);

  }
}
