/* заполняет калькулятор
 */


import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

public class InputCalculator extends ExpenceIncome{


        public void inputCalc(ArrayList<ExpenceIncome> arrayExpenceIncome) throws IOException {
                ExpenceIncome ei = new ExpenceIncome();
                ei.date = DatePeriod();
                Scanner scan = new Scanner(System.in);
                System.out.println(" Введите доход:");
                ei.income = scan.nextInt();
                System.out.println(" Введите расход:");
                ei.expence = scan.nextInt();
                System.out.println(" Введите описание:");
               ei.description = scan.next();
                arrayExpenceIncome.add(ei);


        }

        public  LocalDate DatePeriod() throws IOException {
                Scanner scan = new Scanner(System.in);

                System.out.println("Введите год: ");
                int year = scan.nextInt();
                System.out.println("Введите месяц: ");
                int month = scan.nextInt();
                System.out.println("Введите день: ");
                int day = scan.nextInt();
                return LocalDate.of(year, month, day);

        }
}