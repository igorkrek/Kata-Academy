/* Упорядочивает по дате, выводит сумму дохода за период,
расходов за период, финансовый результат
 */
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.stream.Collectors;


public class MakeCalculator {

    String finRes;

    public ArrayList<ExpenceIncome> MakeCalculator (ArrayList<ExpenceIncome> arrayExpenceIncome,
                                                    LocalDate beginDate, LocalDate endDate) {
        ArrayList<ExpenceIncome> arraySorted = (ArrayList<ExpenceIncome>) arrayExpenceIncome.
                stream().filter(a-> a.date.isAfter(beginDate)).filter(a-> a.date.isBefore(endDate)).sorted(Comparator.comparing(o -> o.date)).collect(Collectors.toList());
        double sumIncome = arrayExpenceIncome.stream().filter(a-> a.date.isAfter(beginDate)).filter(a-> a.date.isBefore(endDate)).map(x -> x.income).reduce((double) 0,(a, b) -> a + b);
        double sumExpence = arrayExpenceIncome.stream().filter(a-> a.date.isAfter(beginDate)).filter(a-> a.date.isBefore(endDate)).map(x -> x.expence).reduce((double) 0,(a, b) -> a + b);

        this.finRes  = "ИТОГО:     " +  sumIncome + " " + sumExpence + " " + (sumIncome-sumExpence);

        return arraySorted;
        }
    public ArrayList<ExpenceIncome> MakeCalculator (ArrayList<ExpenceIncome> arrayExpenceIncome, String finRes) {
        ArrayList<ExpenceIncome> arraySorted = (ArrayList<ExpenceIncome>) arrayExpenceIncome.
                stream().sorted(Comparator.comparing(o -> o.date)).collect(Collectors.toList());
        double sumIncome = arrayExpenceIncome.stream().map(x -> x.income).reduce((double) 0,(a, b) -> a + b);
        double sumExpence = arrayExpenceIncome.stream().map(x -> x.expence).reduce((double) 0,(a, b) -> a + b);

        this.finRes  = "ИТОГО:     " +  sumIncome + " " + sumExpence + " " + (sumIncome-sumExpence);


        return arraySorted;

    }

    }

