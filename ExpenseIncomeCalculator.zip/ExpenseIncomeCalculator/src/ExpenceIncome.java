import java.time.LocalDate;

public class ExpenceIncome {
    LocalDate date;
    double income;
    double expence;
    String  description;

}
