/*записывает в файл
 */

import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class WriteFile {


     public WriteFile(String file, ArrayList<ExpenceIncome> arrayExpenceIncome, String finRes) {

        try (BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(file))) {
        for (ExpenceIncome l : arrayExpenceIncome) {
                LocalDate date = l.date;
                double income = l.income;
                double expence = l.expence;
                String description = l.description;

                    bufferedWriter.write("/" + date.format(DateTimeFormatter.ofPattern("dd-MM-uuuu")) +
                            "/" + income + "/" + expence + "/" + description + "/\n");
                }
            bufferedWriter.write(finRes);
            } catch (IOException e) {System.err.println("Ошибка записи в файл.");
            throw new RuntimeException(e);
        }
    }
}
