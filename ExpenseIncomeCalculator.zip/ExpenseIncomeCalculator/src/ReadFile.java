import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class ReadFile {
    public static ArrayList<ExpenceIncome> ReadFile (String file)  {       //читает из файла в массив  arrayExpenceIncome
    ArrayList<ExpenceIncome> arrayExpenceIncome = new ArrayList<>();
    try (BufferedReader bufferedReader = new BufferedReader(new FileReader(file))) {
        String line = "";
        while ((line = bufferedReader.readLine()) != null) {
            String [] words = line.split("/");
            ExpenceIncome ei = new ExpenceIncome();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-uuuu");

            if (!line.contains("ИТОГО:")) {
                ei.date = LocalDate.parse(words[1], formatter);
                ei.income = Double.parseDouble(words[2]);
                ei.expence = Double.parseDouble(words[3]);
                ei.description = words[4];
                arrayExpenceIncome.add(ei);
            }
        }
    } catch (FileNotFoundException e) {   System.err.println("файл не найден!");
        throw new RuntimeException(e);

    } catch (IOException e) { System.err.println("файл не найден!");
        throw new RuntimeException(e);

    }
    return arrayExpenceIncome;
}

}
