import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

public class FinanceCalculatorTxt extends InputCalculator{
  String file = "C:/Users/user/Desktop/file.txt";
  ArrayList<ExpenceIncome> arrayExpenceIncome = new ArrayList<>();
    String finRes = "";
  public  FinanceCalculatorTxt (String file) throws IOException {
    super();

      int choic = 0;
      while (choic != 3) {
          Scanner scan = new Scanner(System.in);
          System.out.println("0.Посмотреть весь баланс.");
          System.out.println("1.Посмотреть баланс за период.");
          System.out.println("2.Ввести новые данные.");
          System.out.println("3.Выход.");
          choic = scan.nextInt();
          switch (choic) {
              case 0 : {   balans(file); break;}
              case 1 : {
                  InputCalculator inp = new InputCalculator();
              System.out.println("Введите дату начала периода:");
              LocalDate beginDate = inp.DatePeriod();
              System.out.println("Введите дату конца периода:");
              LocalDate endDate = inp.DatePeriod();
              balans(file,beginDate, endDate); break;
          }
              case 2 : {
                  InputFile (this.arrayExpenceIncome);

                      MakeCalculator makeCalculator = new MakeCalculator();
                      this.arrayExpenceIncome = makeCalculator.MakeCalculator(this.arrayExpenceIncome, this.finRes );
                      WriteFile writeFile = new WriteFile(file, this.arrayExpenceIncome, this.finRes);
                      break;
                  }
              case 3 : {
                  WriteFile writeFile = new WriteFile(file, this.arrayExpenceIncome, this.finRes);
                  break;
              }

          }
      }
  }
          public void balans (String file, LocalDate beginDate, LocalDate endDate) {
              System.out.println("Текущий баланс: ");
              System.out.println("дата:      доход:  расход: описание: ");
              ReadFile readFile = new ReadFile();
              this.arrayExpenceIncome = readFile.ReadFile(file);                             // чтение из файла
              MakeCalculator makeCalculator = new MakeCalculator();                               // упорядочивание по дате и выдача итогов
              ArrayList<ExpenceIncome> arrayBalans = makeCalculator.MakeCalculator(this.arrayExpenceIncome, beginDate, endDate);
              for (ExpenceIncome e : arrayBalans) {
                  System.out.println(e.date + " " + e.income + " " +
                          e.expence + " " + e.description);
              }
              this.finRes = makeCalculator.finRes;
              System.out.println(finRes);
          }
        public void balans (String file) {

        System.out.println("Текущий баланс: ");
        System.out.println("дата:      доход:  расход: описание: ");
        ReadFile readFile = new ReadFile();
        this.arrayExpenceIncome = readFile.ReadFile(file);                             // чтение из файла
        MakeCalculator makeCalculator = new MakeCalculator();                               // упорядочивание по дате и выдача итогов
        this.arrayExpenceIncome = makeCalculator.MakeCalculator(this.arrayExpenceIncome, this.finRes);
        for (ExpenceIncome e : this.arrayExpenceIncome) {
            System.out.println(e.date + " " + e.income + " " +
                    e.expence + " " + e.description);
        }
        this.finRes = makeCalculator.finRes;
            WriteFile writeFile = new WriteFile(file, this.arrayExpenceIncome, this.finRes);
        System.out.println(finRes);
    }

    public void InputFile (ArrayList<ExpenceIncome> arrayExpenceIncome) throws IOException {     // запись результатов в файл
      System.out.println("Введите дату новоой финансовой операции: ");
      InputCalculator inputCalculator = new InputCalculator();
      inputCalculator.inputCalc(arrayExpenceIncome); // ввод новых данных
        }
    }


