/*Калькулятор расходов/доходов.
Пользователь может ввести расход/доход: описание, сумму.
В файл сохраняются эти поля + дата записи.
В конец файла сохраняется итог по месяцам.
1. Сделайте базовый класс, и реализации наследников:
на базе txt файла,
csv файла,
html файла.

2. Сделайте класс, который сможет интерактивно работать с этим файлом на базе любого наследника:
дать возможность ввести расход/доход, посмотреть итог за выбранный месяц

3. Сделайте класс, который дает открыть файл с помощью диалога, и в зависимости от типа файла,
передает в работу нужного наследника
 */


import javax.swing.*;
import java.io.File;
import java.io.IOException;

public class Main {


      public static void main(String[] args) throws Exception {



        JFileChooser jFileChooser = new JFileChooser();
        jFileChooser.showOpenDialog(null);
        File file = jFileChooser.getSelectedFile();
        String [] nameParts = file.getName().split("\\.");
        String ext = nameParts[nameParts.length-1];
        if (ext.contains("txt")) {
            FinanceCalculatorTxt financeCalculatorTxt = new FinanceCalculatorTxt("C:/Users/user/Desktop/file.txt");
        }
        if (ext.contains("html")) {
            FinanceCalculatorHtml financeCalculatorHtml = new FinanceCalculatorHtml("C:/Users/user/Desktop/file.txt");
        }
        if (ext.contains("csv")) {
            FinanceCalculatorCsv financeCalculatorCsv = new FinanceCalculatorCsv("C:/Users/user/Desktop/file.csv");
        }

    }
}