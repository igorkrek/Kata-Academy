/*Пререквизиты:

        Api NASA вы легко найдете по запросу в гугле. Из множества апи нас интересует Astronomy Picture of the Day.
        При создании запросов, вместо использования DEMO_KEY лучше зарегистрируйтесь и получите свой ключ. Потому что, DEMO KEY работает на ограниченное количество запросов.


        Задача:

        Пользователь вводит месяц и год.

        Скачать все снимки за месяц в папку.
        Сгенерировать html страницу в этой папке, которая отобразит все скачанные снимки на одной странице.
*/

import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner;

public class collect_photo_NASA {
        public static void collectPhotoNasa() throws IOException {
           //NASA
            //дата

            String path = "C:/Users/user/Desktop/PhotoNasa/";// создание каталога
            Files.createDirectory(Paths.get(path));
            File file= new File("C:/Users/user/Desktop/PhotoNasa/photoNasa.html");
            FileOutputStream fos = new FileOutputStream(file);
            String a="";
            System.out.println("Введите год: ");
            Scanner scan = new Scanner(System.in);
            int year = scan.nextInt();
            System.out.println("Введите месяц: ");
            int month = scan.nextInt()-1;
            int day = 1;

            Calendar calendarNasa = new GregorianCalendar(year, month, day);
            DateFormat dfNasa = new SimpleDateFormat("yyyy-MM-dd");
            for (int i = 0; calendarNasa.get(Calendar.MONTH) == month; i++) {

                String dataNasa = dfNasa.format(calendarNasa.getTime());
                String nasaPhotopage = "https://api.nasa.gov/planetary/apod?api_key=GNNr1CvgO3O71vWmLJ15m0IX6LgcoJL8KxdxRgPa&date=" + dataNasa;
                System.out.println(dataNasa);
                calendarNasa.add(Calendar.DAY_OF_MONTH, +1);
                //сайт со ссылкой
                System.out.println(nasaPhotopage);
                nasaPhotopage = downloadWebPage(nasaPhotopage);
                //нахождение сайта с фото
                int urlBegin = nasaPhotopage.lastIndexOf(",\"url\":");
                int urlEnd = nasaPhotopage.lastIndexOf("}");
                String nasaPhoto = nasaPhotopage.substring(urlBegin + 8, urlEnd - 1);
                System.out.println(nasaPhoto);
                // скачивание описания
            int urlBeginText = nasaPhotopage.lastIndexOf("explanation");
            int urlEndText = nasaPhotopage.lastIndexOf("}");
            String nasaDiscr = nasaPhotopage.substring(urlBeginText + 13, urlEndText -8);

                //скачивание фото в png на рабочий стол
                try (InputStream in = new URL(nasaPhoto).openStream()) {
                    Files.copy(in, Paths.get("C:/Users/user/Desktop/PhotoNasa/nasaPhoto"+i+".png"));
                }
                a ="<img src='nasaPhoto"+i+".png'/>" + "  "+"alt=" +nasaDiscr+">";
                fos.write(a.getBytes());
            }
            fos.close();
        }
            //метод скачивания API
            private static String downloadWebPage (String url) throws IOException {
                StringBuilder result = new StringBuilder();
                String line;
                URLConnection urlConnection = new URL(url).openConnection();
                try (InputStream is = urlConnection.getInputStream();
                     BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
                    while ((line = br.readLine()) != null) {
                        result.append(line);
                    }
                }
                return result.toString();
            }
        }









