import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {

        System.out.println("Collect photo NASA:");
        collect_photo_NASA collectPhotoNasa = new collect_photo_NASA();
        collectPhotoNasa.collectPhotoNasa();
    }
}