import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner;

class jumpRubRate {
    jumpRubRate() throws IOException {
    }

    public static void main(String[] args) throws IOException {
        System.out.println("Найти самые сильные скачки в этот промежуток," +
                " дни, когда курс сильно вырос или упал." +
                " Автоматически скачать текст статьи из википедии, " +
                "отвечающей за факты на эту дату ");
        //ввод даты
        System.out.println("Введите год: ");
        Scanner scan = new Scanner(System.in);
        int year = scan.nextInt();
        System.out.println("Введите месяц: ");
        int month = scan.nextInt()-1;
        Calendar calendar = new GregorianCalendar(year, month, 1);
        int m = month;
        System.out.println("Курс рубля: ");
        DateFormat df = new SimpleDateFormat("yyy/MM/dd");

        String date = "", result, dateUp = date, dateDown = date, rateStr="0";
        float rate = 0, rateBefore=0, rateUp=0, rateDown=0;


        for (int k=1; calendar.get(calendar.MONTH) == m;k++){
            date = df.format(calendar.getTime());
            DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd");
            result = downloadWebPage("https://v6.exchangerate-api.com/v6/f9063b3c4033e8f3e512e89a/history/USD/"+date);


            char a = 'e';rateStr = "0";
            for (int j = result.lastIndexOf("RUB") + 3; a != ','; j++) {
                a = result.charAt(j);
                if ((((int) a) > 45 && ((int) a) < 58)) {
                    rateStr = rateStr.concat(Character.toString(a));
                } else {
                    rate = Float.parseFloat(rateStr);
                }
            }
                date = df1.format(calendar.getTime());
                if (k == 1) {rateBefore=rate; }
                if (rate - rateBefore<0 && rate-rateBefore<rateDown){rateDown=rate - rateBefore;dateDown=date;}
                if (rate - rateBefore>0 && rate-rateBefore>rateUp){rateUp=rate - rateBefore;dateUp=date;}
                rateBefore=rate;

            System.out.println(date + ": " + rate);
            calendar.add(Calendar.DAY_OF_MONTH, +1);
        }
             System.out.println("Наибольший рост: "+dateUp+": "+rateUp);
        System.out.println("Наибольшее падение: "+dateDown+": "+rateDown);


        //статья из википедии на эти даты

        result = downloadWebPage(" https://www.kommersant.ru/archive/rubric/40/day/"+dateUp);
        System.out.println(" https://www.kommersant.ru/archive/rubric/40/day/"+dateUp);
        try {
            File f = new File("C:/Users/user/Desktop/articleUp.html");
            // новый файл
            // Убедимся что он  существует
            if (f.createNewFile())
                System.out.println("File Up created");
            else
                System.out.println("File already exists");
        }
        catch (Exception e) {
            System.err.println(e);
        }


        Path pathUp = Paths.get("C:/Users/user/Desktop/articleUp.html"); //путь к файлу записи

        try {
            Files.writeString(pathUp, result, StandardCharsets.UTF_8);
        } catch (IOException ex) {
                  }
        result = downloadWebPage(" https://www.kommersant.ru/archive/rubric/40/day/"+dateDown);
        try {
            File f = new File("C:/Users/user/Desktop/articleDown.html");
            // новый файл
            // Убедимся что он  существует
            if (f.createNewFile())
                System.out.println("File Down created");
            else
                System.out.println("File already exists");
        }
        catch (Exception e) {
            System.err.println(e);
        }
        Path  pathDown = Paths.get("C:/Users/user/Desktop/articleDown.html"); //путь к файлу записи

        try {
            Files.writeString(pathDown, result, StandardCharsets.UTF_8);
        } catch (IOException ex) {
                 }
    }
      private static String downloadWebPage(String url) throws IOException {
        StringBuilder result = new StringBuilder();
        String line;
        URLConnection urlConnection = new URL(url).openConnection();
        try (InputStream is = urlConnection.getInputStream();
             BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
            while ((line = br.readLine()) != null) {
                result.append(line);
            }
        }
        return result.toString();
    }
}

