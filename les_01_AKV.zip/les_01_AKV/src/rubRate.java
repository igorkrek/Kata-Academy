import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner;
class rubRate {
    public static void main(String[] args) throws IOException {
        System.out.println("Пользователь вводит месяц и год. " +
                "Вывести курс рубля за этот месяц, найти наибольший и наименьшие значения");
        //ввод даты, установка календаря
        System.out.println("Введите год: ");
        Scanner scan = new Scanner(System.in);
        int year = scan.nextInt();
        System.out.println("Введите месяц: ");
        int month = scan.nextInt()-1;
        Calendar calendar = new GregorianCalendar(year, month, 1);
        int m = month;
        System.out.println("Курс рубля: ");
        String date = "", result, dateMax = date, dateMin = date, rateStr="0";
        float rate = 0, rateMax = rate, rateMin = rate;
        DateFormat df = new SimpleDateFormat("yyy/MM/dd");
        //скачивание информации, поиск RUB
        for (int k=1; calendar.get(calendar.MONTH) == m;k++){
            date = df.format(calendar.getTime());
            result = downloadWebPage("https://v6.exchangerate-api.com/v6/f9063b3c4033e8f3e512e89a/history/USD/"+date);
            char a = 'e';rateStr = "0";
            for (int j = result.lastIndexOf("RUB") + 3; a != ','; j++) {
                a = result.charAt(j);
                if ((((int) a) > 45 && ((int) a) < 58)) {
                    rateStr = rateStr.concat(Character.toString(a));
                } else {
                    rate = Float.parseFloat(rateStr);
                }
                //min max
                if (k == 1) {rateMin=rate;rateMax=rate; }
                date = df.format(calendar.getTime());
                if (rateMax < rate) {
                    rateMax = rate;
                    dateMax = date;
                }
                if (rateMin > rate&&rate>0) {
                    rateMin = rate;
                    dateMin = date;
                }
            }
            System.out.println(date + ": " + rate);
            calendar.add(Calendar.DAY_OF_MONTH, +1);
        }
        System.out.println("Max: "+dateMax+"/ "+rateMax);
        System.out.println("Min: "+dateMin+"/ "+rateMin);
    }
    //метод скачивания API
    private static String downloadWebPage(String url) throws IOException {

        StringBuilder result = new StringBuilder();
        String line;
        URLConnection urlConnection = new URL(url).openConnection();
        try (InputStream is = urlConnection.getInputStream();
             BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
            while ((line = br.readLine()) != null) {
                result.append(line);
            }
        }
        return result.toString();
    }
}



