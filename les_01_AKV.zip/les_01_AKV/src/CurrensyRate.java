import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class CurrensyRate {
        public static void main(String[] args) throws IOException {
            System.out.println("Пользователь вводит дату.\n" +
                    "1. Произвести анализ курса валют на эту дату, предыдущую и следующую:\n" +
                    "- Вывести, все три  курса\n" +
                    "- насколько курс вырос/упал.\n" +
                    "- Наибольший и наименьшие значения из этих трех\n" +
                    "- Сохранить в отдельную директорию лучший снимок NASA за эту дату :) \n");
            //ввод даты
            System.out.println("Введите год: ");
            Scanner scan=new Scanner(System.in);
            int year=scan.nextInt();
            System.out.println("Введите месяц: ");
            int month=scan.nextInt()-1;
            System.out.println("Введите день: ");
            int day=scan.nextInt();
            Calendar calendar = new GregorianCalendar(year,month,day);
            DateFormat df = new SimpleDateFormat("yyy/MM/dd");
            String dateNow = df.format(calendar.getTime());
            //календарь и скачивание инфо
            calendar.add(Calendar.DAY_OF_MONTH, -1);
            String dateBefore = df.format(calendar.getTime());
            ArrayList <String> currencyBefore = new ArrayList<>();
            ArrayList <Float> rateBefore = new ArrayList<>();
            String result = downloadWebPage("https://v6.exchangerate-api.com/v6/f9063b3c4033e8f3e512e89a/history/USD/"+df.format(calendar.getTime()));
            curRate(dateBefore,result, currencyBefore,rateBefore);
System.out.println("https://v6.exchangerate-api.com/v6/f9063b3c4033e8f3e512e89a/history/USD/"+df.format(calendar.getTime()));
            calendar.add(Calendar.DAY_OF_MONTH, +1);
            ArrayList <String> currencyNow = new ArrayList<>();
            ArrayList <Float> rateNow = new ArrayList<>();
            result = downloadWebPage("https://v6.exchangerate-api.com/v6/f9063b3c4033e8f3e512e89a/history/USD/"+df.format(calendar.getTime()));
            curRate(dateNow,result, currencyNow,rateNow);

            calendar.add(Calendar.DAY_OF_MONTH, +1);
            String dateAfter = df.format(calendar.getTime());
            ArrayList <String> currencyAfter = new ArrayList<>();
            ArrayList <Float> rateAfter = new ArrayList<>();
            result = downloadWebPage("https://v6.exchangerate-api.com/v6/f9063b3c4033e8f3e512e89a/history/USD/"+df.format(calendar.getTime()));
            curRate(dateAfter,result, currencyAfter,rateAfter);
            //max, min, рост
            System.out.print("       Max:");
            for(int j=0; j<currencyNow.size();j++){System.out.print(currencyNow.get(j)+" ");System.out.print(Math.max(rateBefore.get(j),Math.max(rateNow.get(j),rateAfter.get(j)) )+"/ ");}
            System.out.println();

            System.out.print("       Min:");
            for(int j=0; j<currencyNow.size();j++){System.out.print(currencyNow.get(j)+" ");System.out.print(Math.min(rateBefore.get(j),Math.min(rateNow.get(j),rateAfter.get(j)) )+"/ ");}
            System.out.println();

            float k=0;
            System.out.print("       Рост:");
            for(int j=0; j<currencyNow.size();j++){System.out.print(currencyNow.get(j)+" ");k = rateBefore.get(j)-rateAfter.get(j); System.out.print(k+"/ ");}
            System.out.println();
                                                            //NASA
            //день
            Calendar calendarNasa = new GregorianCalendar(year,month,day);
            DateFormat dfNasa = new SimpleDateFormat("yyyy-MM-dd");
            String dataNasa = dfNasa.format(calendarNasa.getTime());
            //сайт со ссылкой
            String nasaPhotopage = "https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY&date="+dataNasa;
            System.out.println(nasaPhotopage);
            nasaPhotopage = downloadWebPage(nasaPhotopage);
            //нахождение сайта с фото
            int urlBegin = nasaPhotopage.lastIndexOf(",\"url\":");
            int urlEnd = nasaPhotopage.lastIndexOf("}");
            String nasaPhoto=nasaPhotopage.substring(urlBegin+8,urlEnd-1);
            System.out.println(nasaPhoto);

            //скачивание фото в jpg на рабочий стол
            try(InputStream in = new URL(nasaPhoto).openStream()) {
            Files.copy(in, Paths.get("C:/Users/user/Desktop/nasaPhoto.jpg"));
}
}    //метод скачивания API
             private static String downloadWebPage(String url) throws IOException {

                StringBuilder result = new StringBuilder();
                String line;
                URLConnection urlConnection = new URL(url).openConnection();
                try (InputStream is = urlConnection.getInputStream();
                     BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
                        while ((line = br.readLine()) != null) {
                                result.append(line);
                        }
                }
                return result.toString();
        }
        //инициализация массива
        public static void curRate (String data, String result, ArrayList <String> currency,ArrayList <Float> rates ){
            char a;
            String rate="0", cur="";
            int m = 0;
            for(int i=0;i<result.length();i++) {
                a = result.charAt(i);
                if (((int) a) > 64 && ((int) a) < 91) {
                    cur = cur.concat(Character.toString(a));
                    m++;
                }
                if (((((int) a) > 47 && ((int) a) < 58) || (int) a == 46) & m == 3) {
                    rate = rate.concat(Character.toString(a));
                }
                if (a == ',' & m == 3) {
                 currency.add(cur); rates.add(Float.parseFloat(rate));
                    rate = "0";
                    cur = "";
                    m = 0;
                }
            }
            System.out.print(data+": ");
            for(int j=0; j<currency.size();j++){System.out.print(currency.get(j)+" ");System.out.print(rates.get(j)+"/ ");}
            System.out.println();
}
}






