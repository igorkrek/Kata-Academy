import java.io.*;
import java.net.URI;

public class IndianNewsRealis implements IndianNews {

    public IndianNewsRealis() throws IOException {


        String catNumber = IndianNews.categoryChoose();
        System.out.println(catNumber);
        java.awt.Desktop.getDesktop().browse(URI.create(catNumber));
    }



}
