import java.util.Scanner;

public interface IndianNews {
    static String categoryChoose() {
        System.out.println("Выберите категорию новости:");
        String [] cat = {"business", "sports", "world", "politics", "technology", "startup", "entertainment",
                "miscellaneous", "hatke", "science", "automobile"};
                    int i = 0;
                for (String e : cat) {
                    System.out.println(i + ". " + e);
                    i++;
                }
        Scanner scanner = new Scanner(System.in);
        int categoryNumber = scanner.nextInt();
        return  "https://inshortsapi.vercel.app/news?category=" + cat[categoryNumber];
    }
}
