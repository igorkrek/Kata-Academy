/*Поле чудес с соревнованием. Генерируете 1000 случайных слов на сайте-генераторе
(https://sanstv.ru/randomWord)
Сохраняе их в файл. Из файла считываете случайное, и выводите ####... игроки по очереди отгадывают букву.
 Гласная -1 балл, согласная -2 балла, если буква встречается несколько раз - больше. Можно угадать слово
 целиком - за каждую угаданную букву  начисляет баллы(гласные 1, согласные 2).
 Если не угадал-минус 3 балла.
 */



import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {


                Scanner scan = new Scanner(System.in);
                String text= randomWordGet();
                char[] sym = text.toCharArray();//разбиваем на char
                char[] contr = new char[sym.length];// заполняем контрольный массив
                for (int i = 0; i < contr.length; i++) {
                    contr[i] = '#';
                }
                String str = "", cStr = "";
                char c = ' ';
                boolean z = !text.equals(str) & !text.equals(cStr);
                int[] res = {0, 0}; //очки игроков
                while (z) { // пока не угадают
                    for (int j = 0; j < 2 & z; j++) { //игроки
                        System.out.println("введите букву, игрок " + (j + 1) + ":");
                        cStr = scan.nextLine();
                        c = cStr.charAt(0);
                        z = !text.equals(str) & !text.equals(cStr); //считывание слова или буквы
                        if (cStr.equals(text)) {
                            System.out.println(("Угадал слово! Игрок " + (j + 1) + " выиграл!"));
                            System.out.println("счет: " + res[0] + " / " + res[1]);
                            z = false;
                            break;
                        }

                        for (int i = 0; i < contr.length & z; i++) { //проверка букв слова
                            if (sym[i] == c) {
                                contr[i] = sym[i];
                                if (c == 'а' | c == 'у' | c == 'е' | c == 'ы' | c == 'о' | c == 'э' | c == 'я' | c == 'и' | c == 'ю') {
                                    res[j] = res[j] + 1;
                                    System.out.println("угадал! +1 очко");
                                } else {
                                    res[j] = res[j] + 2;
                                    System.out.println("угадал! +2 очка");
                                }
                            }
                        }
                        if (!text.contains(Character.toString(c))) {
                            System.out.println("не угадал... -3 очка");
                            res[j] = res[j] - 3;
                        }
                        str = String.copyValueOf(contr);
                        z = !text.equals(str) & !text.equals(cStr);
                        System.out.println("счет: " + res[0] + " / " + res[1] + " - " + str);
                    }
                }
            }

            public static String randomWordGet() throws IOException {
                String text = downloadWebPage("https://sanstv.ru/randomWord");
                String[] randomWord = new String[1000];
                wordDetect(text, randomWord);// заполняем массив 1000 слов

                File file = new File("file.txt");
                FileOutputStream fos = new FileOutputStream(file);
                for (int i = 0; i < 1000; i++) {
                    text = randomWord[i] + "\n";
                    fos.write(text.getBytes());
                } //массив в файл
                fos.close();

                FileReader fr = new FileReader("file.txt");
                BufferedReader br = new BufferedReader(fr);
                int r = (int) Math.random() * 1000; //считываем из файла случайное слово
                for (int i = 0; i < 1000; i++) {
                    if (i == r) {
                        text = br.readLine();
                    }
                }
                return text;
            }
            //метод скачивания API
            public static String downloadWebPage(String url) throws IOException {
                StringBuilder result = new StringBuilder();
                String line;
                URLConnection urlConnection = new URL(url).openConnection();
                try (InputStream is = urlConnection.getInputStream();
                     BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
                    while ((line = br.readLine()) != null) {
                        result.append(line);
                    }
                }
                return result.toString();
            }

            public static void wordDetect(String result, String[] str) {
                int index1 = 0, index2 = 0, i = 0;
                while (index2 < result.length() & i < 1000) {
                    index1 = result.indexOf("dict/", index1) + 5;
                    index2 = result.indexOf("' target", index1);
                    if (result.substring(index1, index2) != null & !result.substring(index1, index2).contains("CTYPE")) {
                        str[i] = result.substring(index1, index2);
                        i++;
                    }
                    index1++;
                    index2++;
                }
            }
        }

