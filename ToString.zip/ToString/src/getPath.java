
import java.nio.file.Path;
import java.nio.file.Paths;

public class getPath {

public Path getPath(String path){
  Path p = Paths.get(path);
return p;
}
}
