/*Напишите программу, которая сохраняет в файл случайную статью из Википедии.*/

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class WikiPage {


    Path path;
    String result;

    public  WikiPage (String line) {

        try {
            result = downloadWebPage("https://ru.wikipedia.org/wiki/" + line);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
          path = Paths.get("C:/Users/user/Desktop/random_article");
        System.out.println(toString());
        }

        public  String downloadWebPage(String url) throws IOException {
            StringBuilder result = new StringBuilder();
            String line;
            URLConnection urlConnection = new URL(url).openConnection();
            try (InputStream is = urlConnection.getInputStream();
                 BufferedReader br = new BufferedReader(new InputStreamReader(is))) {

                while ((line = br.readLine()) != null) {
                    result.append(line);
                }
            }
            return result.toString();
        }

    @Override
    public String toString() {
        try {
            Files.writeString(this.path, this.result, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


        return this.result;
    }
}










