import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.awt.Desktop;
import java.util.Scanner;

public class browserItunes {
    String artistName;
    String trackName;

    int sdvig=0;
    String [][] media =new String[10][2];
    public void  playSong(String searchRequest) throws IOException {
        String url = buildUrl(searchRequest);  Scanner scan= new Scanner(System.in);
        String page = downloadWebPage(url); System.out.println(page);
        for (int i = 0; i < 10; i++) {
           this.artistName = getTag(page, "artistName");
           this.trackName = getTag(page, "trackName");
            String previewUrl = getTag(page, "previewUrl", sdvig);
            media[i][1] = previewUrl;
            media[i][0] = this.trackName;
            System.out.println(i + ". artistName: " + this.artistName + "- trackName: " + this.trackName);
        }
        System.out.println(" Какой трек скачать? Введите номер:");

        int numberTreck= scan.nextInt();
        mediaDLoad(media[numberTreck][0], media[numberTreck][1]);


    }

    @Override
    public String toString() {
        String info = "<artist>" + this.artistName + "</artist>" + "<track>" + this.trackName + "</track>";
        System.out.println(info);
        return info;
    }

    public String toString (String info) {
String result = "{\"artist:\"" + this.artistName + "\",\n \"track:\"" + this.trackName + "}";
        try {
           Path path = Paths.get("C:/Users/user/Desktop/random_article");
            Files.writeString(path, result, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


        System.out.println(result);
        return result;
    }
    private static void mediaDLoad(String trackName, String previewUrl) throws IOException {
        try (InputStream in = new URL(previewUrl).openStream()) {
            Files.copy(in, Paths.get(trackName + ".m4a"));
        }
        Desktop desktop = Desktop.getDesktop();
        File file = new File(trackName + ".m4a");
        desktop.open(file);
    }


    private String getTag(String page, String tagName) {
        int start = page.indexOf(tagName,sdvig)+tagName.length()+3;
        int end = page.indexOf("\"", start);
        String value = page.substring(start,end);
        return value;
    }
    private String getTag(String page, String tagName,int sdvig) {
        int start = page.indexOf(tagName,sdvig)+tagName.length()+3;
        int end = page.indexOf("\"", start);
        String value = page.substring(start,end);
        this.sdvig=end;
        return value;
    }
    public String buildUrl (String searchRequest) {

        String term = searchRequest.replaceAll(" ", "+");
        String itunesApi = "https://itunes.apple.com/search?term=";
        String limitParam = "&limit=10";
        String mediaParam = "&media=music";
        StringBuilder builder = new StringBuilder();
        builder.append(itunesApi);
        builder.append(term);
        builder.append(limitParam);
        builder.append(mediaParam);
        return builder.toString();
    }
    //метод скачивания API
    private static String downloadWebPage (String url) throws IOException {
        StringBuilder result=new StringBuilder();
        String line;
        URLConnection urlConnection=new URL(url).openConnection();
        try(InputStream is=urlConnection.getInputStream();
            BufferedReader br=new BufferedReader(new InputStreamReader(is))){
            while((line=br.readLine())!=null){
                result.append(line);
            }
        }
        return result.toString();
    }
}