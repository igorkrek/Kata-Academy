import java.io.File;
public class  nameFile extends getPath{
    public nameFile(String name, String path){
        File file = new File(super.getPath(path)+name);
        //System.out.println(file);
    }
}
