/*1.У класса FileInformation из предыдущих уроков сделайте метод toString,
 возвращающий информацию по всем полям.
 2.Реализуйте класс, отображающий страничку в википедии.
 Пусть метод toString у него возвращает текст этой странички. Покажите его использование неявно,
  так:WikiPage wikiPage = new WikiPage(“Java”);System.out.println(wikiPage);
  3.Поймайте в дебаггере метод toString у класса String
  4.Поймайте в дебаггере метод toString у класса Object
  5.Поймайте в дебаггере метод toString у класса StringBuilder
  6.Сделайте метод toString у класса ITunesSong, который возвращает информацию в формате xml: <artist>Rick
  Ross</artist>... и так далее
  7.Сделайте метод toString у класса ITunesSong, который возвращает информацию в формате JSON
 */


import java.io.IOException;
import java.util.Scanner;

public class Main {

    public static void main (String[] args) throws IOException {

        FileInformation fileInformation = new FileInformation();
        fileInformation.toString();

        WikiPage wikiPage = new WikiPage("Java");
        System.out.println(wikiPage);

        browserItunes browserItunes=new browserItunes();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Браузер ITunes. Какую песню ищем?");
        String name = scanner.nextLine();

        browserItunes.playSong(name);
        browserItunes.toString();

        browserItunes.toString("json");
    }
}
