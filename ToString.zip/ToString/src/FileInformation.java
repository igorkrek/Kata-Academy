/*1.У класса FileInformation из предыдущих уроков сделайте метод toString,
 возвращающий информацию по всем полям.2.Реализуйте класс, отображающий страничку в википедии.
 Пусть метод toString у него возвращает текст этой странички. Покажите его использование неявно,
  так:WikiPage wikiPage = new WikiPage(“Java”);System.out.println(wikiPage);
  3.Поймайте в дебаггере метод toString у класса String
  4.Поймайте в дебаггере метод toString у класса Object
  5.Поймайте в дебаггере метод toString у класса StringBuilder
  6.Сделайте метод toString у класса ITunesSong, который возвращает информацию в формате xml: <artist>Rick
  Ross</artist>... и так далее
  7.Сделайте метод toString у класса ITunesSong, который возвращает информацию в формате JSON
 */






public class FileInformation{
    private String path;
    private String fileName;

    public FileInformation () {
    System.out.println("1.Добавьте конструкторы в классы: директория, файл. Самое главное, в базовый класс." );

   this.path = "C:/Users/user/Desktop/";
      for (int i = 0; i < 3; i++) {
      this.fileName = "file" + i + ".txt";
         nameFile nf=new nameFile(fileName, path);

     }



}

   @Override
    public String toString() {

       String str = this.path + this.fileName;
       System.out.println(str);
        return str;

    }
}









