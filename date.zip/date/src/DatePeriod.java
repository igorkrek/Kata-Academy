import java.io.IOException;
import java.time.LocalDate;
import java.util.Scanner;

public class DatePeriod {
    public void DatePeriod() throws IOException {
        Scanner scan=new Scanner(System.in);
        System.out.println("Введите начальную дату: ");
        System.out.println("Введите год: ");
        int year = scan.nextInt();
        System.out.println("Введите месяц: ");
        int month = scan.nextInt();
        System.out.println("Введите день: ");
        int day = scan.nextInt();
        LocalDate dataBegin = LocalDate.of(year, month, day);

        System.out.println("Введите конечную дату: ");
        System.out.println("Введите год: ");
        year = scan.nextInt();
        System.out.println("Введите месяц: ");
        month = scan.nextInt();
        System.out.println("Введите день: ");
        day = scan.nextInt();
        LocalDate dataEnd = LocalDate.of(year, month, day);


        rubRate rr = new rubRate();
        rr.rubRate(dataBegin, dataEnd);

    }
}