import java.io.IOException;
import java.time.*;
import java.util.Scanner;
import java.util.TimeZone;

public class Main {
    public static void main(String[] args) throws IOException {

        System.out.println("1.Выведите все даты текущего года");
        dataOfYear();

        System.out.println("2.“Нарисуйте” календарь:январь пн вт ср чт пт сб вс1  2   3   4  5   6 ... " +
                "и так далее");
        calendar();


        System.out.println("3.В 12 часов 1 января 2020 года вы вылетаете из Москвы во Владивосток," +
                " длительность полета составляет 10 часов 15 минут. " +
                "Вопрос в том, во сколько вы приедете во Владивосток?" +
                " Используйте ZonedDateTime");

        LocalDateTime data = LocalDateTime.of(2020, 01, 01,12,00);
        data=data.plusHours(10).plusMinutes(15);

        ZonedDateTime time = ZonedDateTime.now(ZoneId.of("Europe/Moscow"));
        ZonedDateTime timeV = ZonedDateTime.now(ZoneId.of("Asia/Vladivostok"));
        int delta = (24+timeV.getHour()-time.getHour())>24 ? timeV.getHour()-time.getHour():24+timeV.getHour()-time.getHour();
        System.out.println("Время прилета по Mосковскому времени: "+data+"/ по местному времени: "+data.plusHours(delta));


        System.out.println("4.Пользователь вводит дату, вывести все числа с 1 января того же года до этой даты");
                    Scanner scan=new Scanner(System.in);
                    System.out.println("Введите год: ");
                         int year = scan.nextInt();
                    System.out.println("Введите месяц: ");
                        int month = scan.nextInt();
                    System.out.println("Введите день: ");
                        int day = scan.nextInt();
        dataOfYear(year,month,day);


        System.out.println("5.Калькулятор полетов. Пользователь вводит, из какого часового пояса он вылетает" +
                " (в формате Europe/Moscow, Asia/Vladivostok и так далее.. можно нагуглить для каждого " +
                "города), во сколько, сколько будет лететь. Напишите местное время прилета");

        System.out.println("Список часовых поясов: "+  ZoneId.getAvailableZoneIds());
        System.out.println("Введите часовой пояс вылета: ");
        String zoneTimeDep=scan.next();
        System.out.println("Введите часовой пояс прибытия: ");
        System.out.println("Список часовых поясов: "+  ZoneId.getAvailableZoneIds());
        String zoneTimeArr=scan.next();
        System.out.println("Введите время вылета, час: ");
       int depHour=scan.nextInt();
        System.out.println("Введите время вылета, мин: ");
       int depMin=scan.nextInt();
        System.out.println("Введите время полета, час: ");
        int flyHour=scan.nextInt();
        System.out.println("Введите время полета, мин: ");
        int flyMin=scan.nextInt();
        //zoneTimeDep="Europe/Moscow";zoneTimeArr="Asia/Vladivostok";depHour=10;depMin=30;flyHour=3;flyMin=20;
        int vector=compare(TimeZone.getTimeZone(zoneTimeDep),TimeZone.getTimeZone(zoneTimeArr));

        ZonedDateTime dataDep =  ZonedDateTime.of(2020,01,01,depHour,depMin,00,00, ZoneId.of(zoneTimeDep));
        ZonedDateTime dataArr =  ZonedDateTime.of(2020,01,01,depHour,depMin,00,00, ZoneId.of(zoneTimeArr));
        dataArr=dataArr.plusSeconds(vector);
        System.out.println("Время вылета - в зоне вылета: "+dataDep+"/ в зоне прилета: "+dataArr);
        dataDep=dataDep.plusHours(flyHour).plusMinutes(flyMin);
        dataArr=dataArr.plusHours(flyHour).plusMinutes(flyMin);
        System.out.println("Время прибытия - в зоне вылета: "+dataDep+"/ в зоне прилета: "+dataArr);

        System.out.println("6.Реализуйте класс DatePeriod, в котором будет две LocalDate. " +
                "Переделайте анализатор курса валют, что б он на вход принимал DatePeriod");

            DatePeriod dp=new DatePeriod();
            dp.DatePeriod();

    }
    public static int compare(TimeZone tz1, TimeZone tz2) {
        return (tz2.getRawOffset() - tz1.getRawOffset())/1000;
    }
    public static void dataOfYear() {
        LocalDate thisYear = LocalDate.of(2023, 01, 01);
        while (thisYear.getYear() < 2024) {
            System.out.println(thisYear);
            thisYear = thisYear.plusDays(1);
        }
    }
    public static void dataOfYear(int year,int month,int day) {
        LocalDate thisYear = LocalDate.of(year, 01, 01);
        LocalDate nowTime = LocalDate.of(year,month,day);

        while (!thisYear.equals(nowTime)) {
            System.out.println(thisYear);
            thisYear = thisYear.plusDays(1);
        }
    }



    public static void calendar() {
        LocalDate data = LocalDate.of(2023, 01, 01);

        while (data.getYear() < 2024) {
            printMonth(data);
            data=data.plusMonths(1);
        }
    }
       public static void printMonth(LocalDate data){
           LocalDate dataCurrent = data;
           System.out.println(data.getMonth());
        System.out.println(" MO  TU  WE  TH  FR  SA  SU ");
        String dayWeek = " ";
        String[] week = {"MO", "TU", "WE", "TH", "FR", "SA", "SU"};
        while (dataCurrent.getMonth() == data.getMonth()) {
            for (String i : week) {
                dayWeek = dataCurrent.getDayOfWeek().toString().substring(0, 2);
                if (i.contains(dayWeek)) {
                    if (dataCurrent.getDayOfMonth() < 10) {
                        System.out.print(" " + dataCurrent.getDayOfMonth() + "  ");
                    } else {
                        System.out.print(" " + dataCurrent.getDayOfMonth() + " ");
                    }
                    dataCurrent = dataCurrent.plusDays(1);
                    if(dataCurrent.getMonth() != data.getMonth()){break;}
                } else {
                    System.out.print("    ");
                }
         }
            System.out.println();
        }
    }

}