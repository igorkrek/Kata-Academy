public class product {
    String name;
    int price;

    public product(String name, int price) {
        this.name = name;
        this.price = price;

    }
}
