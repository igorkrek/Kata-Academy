public  class student {
    String name;
    int[] grades;

    public student(String name, int [] grades) {
        this.name = name;
        this.grades = grades;

    }
    public int [] getGrades(){
        return this.grades;

    }
}

