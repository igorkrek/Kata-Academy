/*У вас есть список моделей смартфонов," +
        " iPhone 6 S, Lumia 950, Samsung Galaxy S 6, LG G 4, Nexus 7" +
        "вам нужно вывести в консоль названия двух моделей пропустив при этом первый бренд" +
        " при помощи метода skip и limitimport java.util.ArrayList;

 */
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Main {


        public static void main(String[] args) {

            System.out.println("");
            Stream n =  Stream.of ("iPhone 6 S", "Lumia 950", "Samsung Galaxy S 6", "LG G 4", "Nexus 7");
            n.skip(1).limit(2).forEach(System.out::println);

            System.out.println("У вас есть список моделей смартфонов," +
                    " nokia 3310, samsung galaxy s100, iphone 20, google pixel 10 a" +
                    "вам нужно вывести в консоль названия  моделей c большой буквы");
            Stream name =  Stream.of ("nokia 3310", "samsung galaxy s100", "iphone 20", "google pixel 10 a");
            name.map((a)-> a.toString().substring(0, 1).toUpperCase() + a.toString().substring(1)).forEach(System.out::println);
            Random r = new Random(10);

            System.out.println("6. Необходимо вывести большими буквами названия всех продуктов из магазина электроники, написанного на уроке");
            ArrayList<product> catalog = new ArrayList<>();
            catalog.add(new product("nokia 3310", 110));
            catalog.add(new product("Samsung Galaxy s100", 120));
            catalog.add(new product("iphone 20", 130));
            catalog.add(new product("Google Pixel 10a", 140));
            catalog.stream().map(product -> product.name.toString().toUpperCase()).forEach(System.out::println);


            System.out.println("7. Вам нужно создать класс “Students” с полями “класс” и “оценка”, " +
                    "и попробовать вычислить средний балл у студентов при помощи различных метода (reduce, min/max и т.д.");
            ArrayList<student> students = new ArrayList<>();
            students.add(new student("Vasya", new int []{4,5,5,5}));
            students.add(new student("Petr",  new int []{4,5,5,5}));
            students.add(new student("Vova",  new int []{4,5,5,5}));
            students.add(new student("Gena",  new int []{4,5,5,5}));

            System.out.println(students.stream().map(student -> Arrays.stream(student.grades).average().getAsDouble()).
                    reduce((a1, a2) -> a1+a2).get()/ students.stream().count());

            System.out.println(students.stream().map(student -> Arrays.stream(student.grades).sum()/ 4).reduce(0, Integer::sum)/
                    students.stream().count());

            System.out.println(students.stream().collect(Collectors.summingInt(student -> Arrays.stream(student.grades).sum()))/4/
                    students.stream().count());
        }
    }





