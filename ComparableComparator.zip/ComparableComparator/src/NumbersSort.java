import java.util.Comparator;

public class NumbersSort implements Comparator<Numbers> {

    @Override
    public int compare(Numbers x1, Numbers x2) {

        if (x1.getNum() > x2.getNum()) {
            return 1;
        }
        if (x1.getNum() == x2.getNum()) {
            return 0;
        }
        return -1;
    }

}

