public class Numbers implements Comparable <Numbers> {
    int num;

    public int getNum() {
        return num;
    }

    public Numbers(int num) {
        this.num = num;
    }

    @Override
    public int compareTo(Numbers numbers) {

        if (numbers.getNum() % 2 ==0) {
            return 1;
        }
        if (this.num == numbers.getNum()) {
            return 0;
        }
        return -1;
    }

}




