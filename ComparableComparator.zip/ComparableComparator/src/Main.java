/*ужно отсортировать случайный список чисел.
Числа нужно отсортировать следующим образом:
Четные идут в начале по возрастанию,
нечетные по убыванию в конце списка.
*/


import java.util.Arrays;



public class Main {
    public static void main(String[] args) {

        System.out.println("НЕотсортированный массив:");

        Numbers [] list = new Numbers[20];
        for (int i=0; i < list.length; i++) {
            double k = Math.random() * 20 - 10;
           list[i] = new Numbers((int) k);
            System.out.println(list[i].getNum());
        }
        System.out.println("Отсортированный массив:");

        Arrays.sort(list, new NumbersSort());
        Arrays.sort(list);


            for (Numbers i:list){
                 System.out.println(i.getNum());
         }
    }
}