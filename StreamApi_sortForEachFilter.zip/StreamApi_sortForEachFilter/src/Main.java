import java.util.Random;
import java.util.stream.IntStream;

public class Main {
    public static void main(String[] args) {

        Random random = new Random();
        IntStream.generate(() -> random.nextInt(21) - 10).filter((a) -> a > 0).limit(10).sorted().forEach(System.out::println);


    }
}