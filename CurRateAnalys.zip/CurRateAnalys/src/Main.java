/* Производит анализ курса валют на  дату, предыдущую и следующую. Выводит, все три  курса.
Величину падения и роста, наибольший и наименьшие значения из этих трех, сохраняет в отдельную директорию лучший
снимок NASA за эту дату
 */
import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
public class Main {
    public static void main(String[] args) throws IOException {


                //ввод даты
                System.out.println("Введите год: ");
                Scanner scan=new Scanner(System.in);
                int year=scan.nextInt();
                System.out.println("Введите месяц: ");
                int month=scan.nextInt()-1;
                System.out.println("Введите день: ");
                int day=scan.nextInt();
                Calendar calendar = new GregorianCalendar(year,month,day);
                DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
                String dateNow = df.format(calendar.getTime());
                //календарь и скачивание инфо
                calendar.add(Calendar.DAY_OF_MONTH, -1);
                String dateBefore = df.format(calendar.getTime());
                ArrayList <String> currencyBefore = new ArrayList<>();
                ArrayList <Float> rateBefore = new ArrayList<>();
                String result = downloadWebPage("http://www.cbr.ru/scripts/XML_daily.asp?date_req="+df.format(calendar.getTime()));
                curRate(dateBefore,result, currencyBefore,rateBefore);
                System.out.println("http://www.cbr.ru/scripts/XML_daily.asp?date_req="+df.format(calendar.getTime()));
                calendar.add(Calendar.DAY_OF_MONTH, +1);
                ArrayList <String> currencyNow = new ArrayList<>();
                ArrayList <Float> rateNow = new ArrayList<>();
                result = downloadWebPage("http://www.cbr.ru/scripts/XML_daily.asp?date_req="+df.format(calendar.getTime()));
                curRate(dateNow,result, currencyNow,rateNow);

                calendar.add(Calendar.DAY_OF_MONTH, +1);
                String dateAfter = df.format(calendar.getTime());
                ArrayList <String> currencyAfter = new ArrayList<>();
                ArrayList <Float> rateAfter = new ArrayList<>();
                result = downloadWebPage("http://www.cbr.ru/scripts/XML_daily.asp?date_req="+df.format(calendar.getTime()));
                curRate(dateAfter,result, currencyAfter,rateAfter);
                //max, min, рост
                System.out.print("       Max:");
                for(int j=0; j<currencyNow.size();j++){
                    System.out.print(currencyNow.get(j)+" ");
                    System.out.print(Math.max(rateBefore.get(j),Math.max(rateNow.get(j),rateAfter.get(j)) )+"/ ");}
                System.out.println();

                System.out.print("       Min:");
                for(int j=0; j<currencyNow.size();j++){
                    System.out.print(currencyNow.get(j)+" ");
                    System.out.print(Math.min(rateBefore.get(j),Math.min(rateNow.get(j),rateAfter.get(j)) )+"/ ");}
                System.out.println();

                float k=0;
                System.out.print("       Рост:");
                for(int j=0; j<currencyNow.size();j++){
                    System.out.print(currencyNow.get(j)+" ");
                    k = rateBefore.get(j)-rateAfter.get(j);
                    System.out.print(k+"/ ");}
                System.out.println();
                //NASA
                //день
                Calendar calendarNasa = new GregorianCalendar(year,month,day);
                DateFormat dfNasa = new SimpleDateFormat("yyyy-MM-dd");
                String dataNasa = dfNasa.format(calendarNasa.getTime());
                //сайт со ссылкой
                String nasaPhotopage = "https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY&date="+dataNasa;
                System.out.println(nasaPhotopage);
                nasaPhotopage = downloadWebPage(nasaPhotopage);
                //нахождение сайта с фото
                int urlBegin = nasaPhotopage.lastIndexOf(",\"url\":");
                int urlEnd = nasaPhotopage.lastIndexOf("}");
                String nasaPhoto=nasaPhotopage.substring(urlBegin+8,urlEnd-1);
                System.out.println(nasaPhoto);

                //скачивание фото в jpg на рабочий стол
                try(InputStream in = new URL(nasaPhoto).openStream()) {
                    Files.copy(in, Paths.get("C:/Users/user/Desktop/nasaPhoto.jpg"));
                }
            }    //метод скачивания API
            private static String downloadWebPage(String url) throws IOException {

                StringBuilder result = new StringBuilder();
                String line;
                URLConnection urlConnection = new URL(url).openConnection();
                try (InputStream is = urlConnection.getInputStream();
                     BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
                    while ((line = br.readLine()) != null) {
                        result.append(line);
                    }
                }
                return result.toString();
            }
            //инициализация массива
            public static void curRate (String data, String result, ArrayList <String> currency,ArrayList <Float> rates ){
                String rate= result.substring(result.indexOf("USD")+64, result.indexOf("USD")+71),
                        cur="USD";
                System.out.println(data+": " + rate + " / " + cur);
                currency.add(cur);
                rates.add(Float.parseFloat(rate.replace(',', '.')));
                for(int j=0; j<currency.size();j++)
                    System.out.println(data+": " + currency.get(j)+" " + rates.get(j)+"/ ");

            }
        }







