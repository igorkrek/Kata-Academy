import java.io.IOException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws fileUrlException, IOException {
       System.out.println("В чем разница между throw и throws в Java?");
       System.out.println("2.Пользователь вводит число. Если произошла ошибка ввода, выведите пользователю сообщение о том, что ввод некорректный");
      try {
          System.out.println("Введите число: ");
          Scanner scan = new Scanner(System.in);
          char x = scan.next().charAt(0);
          if (!Character.isDigit(x)) {
              throw new RuntimeException("введена не цифра");
          }
      int num=(int) x-48;
      System.out.println(num);
      }
                    catch (RuntimeException e) {
                        System.out.println("Ошибка!");
                    }
        System.out.println("3.Пользователь вводит число. Если произошла ошибка ввода, дайте пользователю ввести еще раз: так пока он не введёт нормально (подсказка: while)");
        char x='q';
      while (!Character.isDigit(x))
      try {
        Scanner scan = new Scanner(System.in);
        System.out.println("Введите число: ");
        x = scan.next().charAt(0);
            if (!Character.isDigit(x)) {
                throw new RuntimeException("введена не цифра");}
        int num=(int) x-48;
        System.out.println(num);
    }
                    catch (RuntimeException e) {
        System.out.println("Ошибка!");
    }
        System.out.println("4.Доработайте калькулятор. Если пользователь ввел неверное значение, просто дайте ему ввести еще раз. (Пока он не введёт корректно)");
        calculator calculator=new calculator();

        System.out.println("5.Пользователь вводит адрес ссылки. " +
                "Если удаётся скачать страничку по адресу, сохранить ее в html файл; " +
                "иначе вывести, что страница не найдена.");
        System.out.println("Введите url:");
        Scanner scan = new Scanner(System.in);
        String url=scan.next();
        //url="https://setfor.ru/"
            fileUrl fileUrl=new fileUrl(url);


            System.out.println("6.Пользователь вводит имя файла. Выведите содержимое этого файла, если не получилось -выведите сообщение, что файл не найден");

        System.out.println("Введите имя файла:");
        String name=scan.next();
        name="C:/Users/user/Desktop/2023-06-18_13-34-12.png";
        fileOutput fileOutput=new fileOutput(name);

        System.out.println("7.Доработайте скачивальщик снимков NASA, " +
                "чтобы в нем не было ни одного throws (пройдитесь прям поиском по файлу). " +
                "Throws придётся заменить на try catch.");
                    nasa nasa=new nasa();




    }
}