import java.io.*;

import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner;

public class nasa {
    public nasa() {
        System.out.println("Пререквизиты:\n" +
                "1. Api NASA вы легко найдете по запросу в гугле. Из множества апи нас интересует Astronomy Picture of the Day.\n" +
                "2. При создании запросов, вместо использования DEMO_KEY лучше зарегистрируйтесь и получите свой ключ. Потому что, DEMO KEY работает на ограниченное количество запросов.\n" +
                "\n" +
                "Задача:\n" +
                "Пользователь вводит месяц и год. \n" +
                "1. Скачать все снимки за месяц в папку.\n" +
                "2. Сгенерировать html страницу в этой папке, которая отобразит все скачанные снимки на одной странице. Пример:\n" +
                "<img src=“1.png”/>\n" +
                "<img src=“2.png”/>\n");

        //NASA
        //дата
        File file = new File("C:/Users/user/Desktop/PhotoNasa/photoNasa.html");
        String path = "C:/Users/user/Desktop/PhotoNasa/";// создание каталога

        try {
            Files.createDirectory(Paths.get(path));
            FileOutputStream fos = new FileOutputStream(file);
            String a = "";

            Scanner scan = new Scanner(System.in);
            System.out.println("Введите год: ");
            int year = scan.nextInt();
            System.out.println("Введите месяц: ");
            int month = scan.nextInt();
            int day = 1;

            Calendar calendarNasa = new GregorianCalendar(year, month, day);
            DateFormat dfNasa = new SimpleDateFormat("yyyy-MM-dd");
            for (int i = 0; calendarNasa.get(Calendar.MONTH) == month; i++) {

                String dataNasa = dfNasa.format(calendarNasa.getTime());
                String nasaPhotopage = "https://api.nasa.gov/planetary/apod?api_key=GNNr1CvgO3O71vWmLJ15m0IX6LgcoJL8KxdxRgPa&date=" + dataNasa;
                System.out.println(dataNasa);
                calendarNasa.add(Calendar.DAY_OF_MONTH, +1);

                //сайт со ссылкой
                System.out.println(nasaPhotopage);
                nasaPhotopage = downloadWebPage(nasaPhotopage);
                //нахождение сайта с фото
                int urlBegin = nasaPhotopage.lastIndexOf(",\"url\":");
                int urlEnd = nasaPhotopage.lastIndexOf("}");
                String nasaPhoto = nasaPhotopage.substring(urlBegin + 8, urlEnd - 1);
                System.out.println(nasaPhoto);

                // скачивание описания
                int urlBeginText = nasaPhotopage.lastIndexOf("explanation");
                int urlEndText = nasaPhotopage.lastIndexOf("}");
                String nasaDiscr = nasaPhotopage.substring(urlBeginText + 13, urlEndText - 8);

                //скачивание фото в png на рабочий стол

                try (InputStream in = new URL(nasaPhoto).openStream()) {
                    Files.copy(in, Paths.get("C:/Users/user/Desktop/PhotoNasa/nasaPhoto" + i + ".png"));
                } catch (IOException e) {
                    System.out.println("неверный ввод");
                }


                a = "<img src='nasaPhoto" + i + ".png'/>" + "  " + "alt=" + nasaDiscr + ">";
                fos.write(a.getBytes());
            }

        } catch (Exception e) {
            System.out.println("неверный ввод");
        }
    }

    //метод скачивания API
    private static String downloadWebPage(String url) {

        try {
            StringBuilder result = new StringBuilder();
            String line;
            URLConnection urlConnection = new URL(url).openConnection();
            try (InputStream is = urlConnection.getInputStream();
                 BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
                while ((line = br.readLine()) != null) {
                    result.append(line);
                }
            }

            url=result.toString();
        } catch (Exception e) {
            System.out.println("неверный ввод");
        }return url;
    }

}










