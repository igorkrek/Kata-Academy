import java.util.Scanner;

public class calculator {

          public calculator() {
            System.out.println("Сделать калькулятор для трех чисел: пользователь вводит первое, потом оператор, второе, оператор, третье. Посчитать первое на второе, потом результат с третьим. Пример:11+4*20Вывод: 300");

            Scanner scan=new Scanner(System.in);
            System.out.println("Решить предыдущую задачу, но операции считать по приоритету (умножение и деление выше сложения вычитания).");
            System.out.println("Введите 1 число:");
            int x1= enterSymbol();

            System.out.println("+,-,*,/");
            String o1 = scan.next();
            if (!"+,-,*,/".contains(o1)) {
                throw new RuntimeException("ошибка введени операции");
            }
            System.out.println("Введите 2 число:");
           int x2 = enterSymbol();
            System.out.println("+,-,*,/");
            String o2 = scan.next();
            if (!"+,-,*,/".contains(o2)) {
                throw new RuntimeException("ошибка введени операции");
            }
            System.out.println("Введите 3 число:");
            int x3 = enterSymbol();
            switch (o1 + o2) {
                case "++":
                    System.out.println(x1 + x2 + x3);
                    break;
                case "+-":
                    System.out.println(x1 + x2 - x3);
                    break;
                case "+*":
                    System.out.println(x1 + x2 * x3);
                    break;
                case "+/":
                    System.out.println(x1 + x2 / x3);
                    break;
                case "-+":
                    System.out.println(x1 - x2 + x3);
                    break;
                case "--":
                    System.out.println(x1 - x2 - x3);
                    break;
                case "-*":
                    System.out.println(x1 - x2 * x3);
                    break;
                case "-/":
                    System.out.println(x1 - x2 / x3);
                    break;
                case "*+":
                    System.out.println(x1 * x2 + x3);
                    break;
                case "*-":
                    System.out.println(x1 * x2 - x3);
                    break;
                case "**":
                    System.out.println(x1 * x2 * x3);
                    break;
                case "*/":
                    System.out.println(x1 * x2 / x3);
                    break;
                case "/+":
                    System.out.println(x1 / x2 + x3);
                    break;
                case "/-":
                    System.out.println(x1 / x2 - x3);
                    break;
                case "/*":
                    System.out.println(x1 / x2 * x3);
                    break;
                case "//":
                    System.out.println(x1 / x2 / x3);
                    break;
            }
        }

        public int enterSymbol() {
            char x = 'q'; int num=0;
            while (!Character.isDigit(x)){
                try {
                    Scanner scan = new Scanner(System.in);
                    System.out.println("Введите число: ");
                    x = scan.next().charAt(0);
                    if (!Character.isDigit(x)) {
                        throw new RuntimeException("введена не цифра");
                    }
                    num=(int) x-48;

                } catch (RuntimeException e) {
                    System.out.println("Ошибка!");
                }


            }
            return  num;
        }
    }





