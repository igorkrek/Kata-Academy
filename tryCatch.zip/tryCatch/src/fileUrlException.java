import java.io.IOException;

public class fileUrlException extends IOException{
    public fileUrlException(){
        super();

    }
    public fileUrlException(String e){
        super(e);

    }
}
