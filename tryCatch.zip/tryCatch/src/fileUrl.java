import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.net.UnknownHostException;

public class fileUrl {
    public fileUrl(String url) throws IOException {


            File file= new File("C:/Users/user/Desktop/file.html");
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(downloadWebPage(url).getBytes());
            fos.close();

}
        //метод скачивания API
        private static String downloadWebPage (String url) throws IOException {
            StringBuilder result = new StringBuilder();
            String line;
            URLConnection urlConnection = new URL(url).openConnection();
            try (InputStream is = urlConnection.getInputStream();
                 BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
                while ((line = br.readLine()) != null) {
                    result.append(line);
                }
            }
            catch (UnknownHostException e) {
                System.err.println("страница не найдена"); }
            return result.toString();
        }
    }




