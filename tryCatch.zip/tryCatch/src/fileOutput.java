import java.io.*;
public class fileOutput {
          public fileOutput(String name) throws IOException {

              try (BufferedReader reader = new BufferedReader(new FileReader(name))) {
                  String line;
                  while ((line = reader.readLine()) != null) {
                      System.out.println(line + "\n");
                  }
              }
              catch (IOException e) {
                 System.err.println("файл не найден");
              }


        }

    }






