import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) throws IOException {
//        System.out.println("1.Пользователь вводит 10 слов в массив. Найдите первое слово, в котором есть две гласные буквы подряд");
//        Scanner scan = new Scanner(System.in);
//        String[] s  = new String[10];
//        for (int i = 0; i < 10; i++) {
//            System.out.println("введите слово:");
//            s[i]=scan.nextLine();}
//        //String[] s  = {"олово","нуклон","фиолетово","веденеево","жара","климат","киреево","жесть","корова","тиберий"};
//            String wordChar ="аеёиоуыэюяaeiouyАЕЁИОУЫЭЮЯAEIOUY";boolean con=true;
//            for(int i=0;i<10&con;i++){
//            for (int j = 0; (j < s[i].length()-2)&con; j++) {
//                if (wordChar.contains(s[i].substring(j,j+1))&
//                        wordChar.contains(s[i].substring(j+1,j+2))) {System.out.println("первое слово с двумя гласными подряд: "+s[i]);con=false;}
//            }
//        }
   //     System.out.println("2.Пользователь вводит массив чисел. Найдите первое четное число");
//        int[] x  = new int [10];
//        for (int i = 0; i < 10; i++) {
//            System.out.println("введите число:");
//            x[i]=scan.nextInt();}
//      //  int[] x={1,2,3,4,5,6,7,8,9,10,255,387,400,873};
//        for (int i:x) {if (i%2==0){System.out.println("первое четное число: "+i);break; }}

//        System.out.println("3.Найдите первое чётное число в массиве, которое больше 100");
//         int[] x1={1,2,3,4,5,6,7,8,9,10,255,387,400,873};
//        for (int i:x1) {if (i%2==0&i>100){System.out.println("первое четное число, большее 100: "+i);break; }}
//
//        System.out.println("4.Найдите последнее слово в массиве, которое написано ЗаБоРчИкОм" +
//                " (что б узнать, заглавная ли буква, используйте Character.isUpperCase(letter)" );
//            String [] text ={"торт","ГаЛеРеЯ","рыба","СТОЛ","ПрОгРаМмА","робот","РЕКА","МиЛлИаРд","крепость","ФИНАЛ"};
//       boolean cont=true;
//           aa: for(int i=text.length-1;i>0;i--){
//              cont= Character.isUpperCase(text[i].charAt(0));
//            for (int j = 1; (j < text[i].length()); j++) {
//             if(Character.isUpperCase(text[i].charAt(j))==!cont){cont=Character.isUpperCase(text[i].charAt(j));}
//                    else break;
//                    if (j==text[i].length()-1){System.out.println("последнее слово заборчиком: "+text[i]);break aa;}
//            }

//        System.out.println("5.Выводите числа от 1 до того момента, как сумма всех цифр в числе не будет равна 20" +
//                " (пример такого числа -875)");int sum=0;
//            for(int i=1;sum<20;i++){sum= i/100+(i-i/100*100)/10+(i-i/10*10);
//                System.out.println( i+" "+sum);
//            }

//        System.out.println("6.Выведите все даты невисокосного года. В январе 31 день, феврале -28, далее чередуется -в марте 31, в апреле 30...");
//        Calendar calen = new GregorianCalendar(2022, 00, 01);
//        DateFormat df = new SimpleDateFormat("dd / MM / yyyy");
//       while (calen.get(Calendar.YEAR)==2022) {
//           System.out.println( df.format(calen.getTime()));
//           calen.add(Calendar.DAY_OF_MONTH, +1);}

        System.out.println(" 7.Сохраняйте снимки NASA с 1 января, пока в поле Explanation нет слова “Earth”");

                nasa n=new nasa();
                n.nasa();


    }
        }





