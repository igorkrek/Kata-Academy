package com.example.demo.serveses;


import org.springframework.stereotype.Component;

@Component
public class TestService {
    public String appleName = "Apple";
    public boolean setAppleName(String appleName) {
            this.appleName = appleName.toLowerCase();
            return true;
        }

    }

