package com.example.demo.repository;

public interface UserRepositiry {
    public void userRepo();
}
